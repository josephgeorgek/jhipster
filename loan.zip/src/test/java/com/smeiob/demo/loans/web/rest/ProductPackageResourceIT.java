package com.smeiob.demo.loans.web.rest;

import com.smeiob.demo.loans.LoansApp;
import com.smeiob.demo.loans.domain.ProductPackage;
import com.smeiob.demo.loans.domain.Customer;
import com.smeiob.demo.loans.repository.ProductPackageRepository;
import com.smeiob.demo.loans.service.ProductPackageService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;
import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.smeiob.demo.loans.domain.enumeration.ApplicationStatus;
/**
 * Integration tests for the {@link ProductPackageResource} REST controller.
 */
@SpringBootTest(classes = LoansApp.class)
@AutoConfigureMockMvc
@WithMockUser
public class ProductPackageResourceIT {

    private static final Instant DEFAULT_PLACED_DATE = Instant.ofEpochMilli(0L);
    private static final Instant UPDATED_PLACED_DATE = Instant.now().truncatedTo(ChronoUnit.MILLIS);

    private static final ApplicationStatus DEFAULT_STATUS = ApplicationStatus.DRAFT;
    private static final ApplicationStatus UPDATED_STATUS = ApplicationStatus.COMPLETED;

    private static final String DEFAULT_CODE = "AAAAAAAAAA";
    private static final String UPDATED_CODE = "BBBBBBBBBB";

    private static final Long DEFAULT_FACILITY_ID = 1L;
    private static final Long UPDATED_FACILITY_ID = 2L;

    @Autowired
    private ProductPackageRepository productPackageRepository;

    @Autowired
    private ProductPackageService productPackageService;

    @Autowired
    private EntityManager em;

    @Autowired
    private MockMvc restProductPackageMockMvc;

    private ProductPackage productPackage;

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static ProductPackage createEntity(EntityManager em) {
        ProductPackage productPackage = new ProductPackage()
            .placedDate(DEFAULT_PLACED_DATE)
            .status(DEFAULT_STATUS)
            .code(DEFAULT_CODE)
            .facilityId(DEFAULT_FACILITY_ID);
        // Add required entity
        Customer customer;
        if (TestUtil.findAll(em, Customer.class).isEmpty()) {
            customer = CustomerResourceIT.createEntity(em);
            em.persist(customer);
            em.flush();
        } else {
            customer = TestUtil.findAll(em, Customer.class).get(0);
        }
        productPackage.setCustomer(customer);
        return productPackage;
    }
    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static ProductPackage createUpdatedEntity(EntityManager em) {
        ProductPackage productPackage = new ProductPackage()
            .placedDate(UPDATED_PLACED_DATE)
            .status(UPDATED_STATUS)
            .code(UPDATED_CODE)
            .facilityId(UPDATED_FACILITY_ID);
        // Add required entity
        Customer customer;
        if (TestUtil.findAll(em, Customer.class).isEmpty()) {
            customer = CustomerResourceIT.createUpdatedEntity(em);
            em.persist(customer);
            em.flush();
        } else {
            customer = TestUtil.findAll(em, Customer.class).get(0);
        }
        productPackage.setCustomer(customer);
        return productPackage;
    }

    @BeforeEach
    public void initTest() {
        productPackage = createEntity(em);
    }

    @Test
    @Transactional
    public void createProductPackage() throws Exception {
        int databaseSizeBeforeCreate = productPackageRepository.findAll().size();
        // Create the ProductPackage
        restProductPackageMockMvc.perform(post("/api/product-packages")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(productPackage)))
            .andExpect(status().isCreated());

        // Validate the ProductPackage in the database
        List<ProductPackage> productPackageList = productPackageRepository.findAll();
        assertThat(productPackageList).hasSize(databaseSizeBeforeCreate + 1);
        ProductPackage testProductPackage = productPackageList.get(productPackageList.size() - 1);
        assertThat(testProductPackage.getPlacedDate()).isEqualTo(DEFAULT_PLACED_DATE);
        assertThat(testProductPackage.getStatus()).isEqualTo(DEFAULT_STATUS);
        assertThat(testProductPackage.getCode()).isEqualTo(DEFAULT_CODE);
        assertThat(testProductPackage.getFacilityId()).isEqualTo(DEFAULT_FACILITY_ID);
    }

    @Test
    @Transactional
    public void createProductPackageWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = productPackageRepository.findAll().size();

        // Create the ProductPackage with an existing ID
        productPackage.setId(1L);

        // An entity with an existing ID cannot be created, so this API call must fail
        restProductPackageMockMvc.perform(post("/api/product-packages")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(productPackage)))
            .andExpect(status().isBadRequest());

        // Validate the ProductPackage in the database
        List<ProductPackage> productPackageList = productPackageRepository.findAll();
        assertThat(productPackageList).hasSize(databaseSizeBeforeCreate);
    }


    @Test
    @Transactional
    public void checkPlacedDateIsRequired() throws Exception {
        int databaseSizeBeforeTest = productPackageRepository.findAll().size();
        // set the field null
        productPackage.setPlacedDate(null);

        // Create the ProductPackage, which fails.


        restProductPackageMockMvc.perform(post("/api/product-packages")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(productPackage)))
            .andExpect(status().isBadRequest());

        List<ProductPackage> productPackageList = productPackageRepository.findAll();
        assertThat(productPackageList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkStatusIsRequired() throws Exception {
        int databaseSizeBeforeTest = productPackageRepository.findAll().size();
        // set the field null
        productPackage.setStatus(null);

        // Create the ProductPackage, which fails.


        restProductPackageMockMvc.perform(post("/api/product-packages")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(productPackage)))
            .andExpect(status().isBadRequest());

        List<ProductPackage> productPackageList = productPackageRepository.findAll();
        assertThat(productPackageList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkCodeIsRequired() throws Exception {
        int databaseSizeBeforeTest = productPackageRepository.findAll().size();
        // set the field null
        productPackage.setCode(null);

        // Create the ProductPackage, which fails.


        restProductPackageMockMvc.perform(post("/api/product-packages")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(productPackage)))
            .andExpect(status().isBadRequest());

        List<ProductPackage> productPackageList = productPackageRepository.findAll();
        assertThat(productPackageList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllProductPackages() throws Exception {
        // Initialize the database
        productPackageRepository.saveAndFlush(productPackage);

        // Get all the productPackageList
        restProductPackageMockMvc.perform(get("/api/product-packages?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(productPackage.getId().intValue())))
            .andExpect(jsonPath("$.[*].placedDate").value(hasItem(DEFAULT_PLACED_DATE.toString())))
            .andExpect(jsonPath("$.[*].status").value(hasItem(DEFAULT_STATUS.toString())))
            .andExpect(jsonPath("$.[*].code").value(hasItem(DEFAULT_CODE)))
            .andExpect(jsonPath("$.[*].facilityId").value(hasItem(DEFAULT_FACILITY_ID.intValue())));
    }
    
    @Test
    @Transactional
    public void getProductPackage() throws Exception {
        // Initialize the database
        productPackageRepository.saveAndFlush(productPackage);

        // Get the productPackage
        restProductPackageMockMvc.perform(get("/api/product-packages/{id}", productPackage.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.id").value(productPackage.getId().intValue()))
            .andExpect(jsonPath("$.placedDate").value(DEFAULT_PLACED_DATE.toString()))
            .andExpect(jsonPath("$.status").value(DEFAULT_STATUS.toString()))
            .andExpect(jsonPath("$.code").value(DEFAULT_CODE))
            .andExpect(jsonPath("$.facilityId").value(DEFAULT_FACILITY_ID.intValue()));
    }
    @Test
    @Transactional
    public void getNonExistingProductPackage() throws Exception {
        // Get the productPackage
        restProductPackageMockMvc.perform(get("/api/product-packages/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateProductPackage() throws Exception {
        // Initialize the database
        productPackageService.save(productPackage);

        int databaseSizeBeforeUpdate = productPackageRepository.findAll().size();

        // Update the productPackage
        ProductPackage updatedProductPackage = productPackageRepository.findById(productPackage.getId()).get();
        // Disconnect from session so that the updates on updatedProductPackage are not directly saved in db
        em.detach(updatedProductPackage);
        updatedProductPackage
            .placedDate(UPDATED_PLACED_DATE)
            .status(UPDATED_STATUS)
            .code(UPDATED_CODE)
            .facilityId(UPDATED_FACILITY_ID);

        restProductPackageMockMvc.perform(put("/api/product-packages")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(updatedProductPackage)))
            .andExpect(status().isOk());

        // Validate the ProductPackage in the database
        List<ProductPackage> productPackageList = productPackageRepository.findAll();
        assertThat(productPackageList).hasSize(databaseSizeBeforeUpdate);
        ProductPackage testProductPackage = productPackageList.get(productPackageList.size() - 1);
        assertThat(testProductPackage.getPlacedDate()).isEqualTo(UPDATED_PLACED_DATE);
        assertThat(testProductPackage.getStatus()).isEqualTo(UPDATED_STATUS);
        assertThat(testProductPackage.getCode()).isEqualTo(UPDATED_CODE);
        assertThat(testProductPackage.getFacilityId()).isEqualTo(UPDATED_FACILITY_ID);
    }

    @Test
    @Transactional
    public void updateNonExistingProductPackage() throws Exception {
        int databaseSizeBeforeUpdate = productPackageRepository.findAll().size();

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restProductPackageMockMvc.perform(put("/api/product-packages")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(productPackage)))
            .andExpect(status().isBadRequest());

        // Validate the ProductPackage in the database
        List<ProductPackage> productPackageList = productPackageRepository.findAll();
        assertThat(productPackageList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    public void deleteProductPackage() throws Exception {
        // Initialize the database
        productPackageService.save(productPackage);

        int databaseSizeBeforeDelete = productPackageRepository.findAll().size();

        // Delete the productPackage
        restProductPackageMockMvc.perform(delete("/api/product-packages/{id}", productPackage.getId())
            .accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<ProductPackage> productPackageList = productPackageRepository.findAll();
        assertThat(productPackageList).hasSize(databaseSizeBeforeDelete - 1);
    }
}
