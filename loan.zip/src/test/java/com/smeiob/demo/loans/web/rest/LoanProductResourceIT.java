package com.smeiob.demo.loans.web.rest;

import com.smeiob.demo.loans.LoansApp;
import com.smeiob.demo.loans.domain.LoanProduct;
import com.smeiob.demo.loans.domain.Product;
import com.smeiob.demo.loans.domain.ProductPackage;
import com.smeiob.demo.loans.repository.LoanProductRepository;
import com.smeiob.demo.loans.service.LoanProductService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;
import javax.persistence.EntityManager;
import java.math.BigDecimal;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.smeiob.demo.loans.domain.enumeration.LoanProductStatus;
/**
 * Integration tests for the {@link LoanProductResource} REST controller.
 */
@SpringBootTest(classes = LoansApp.class)
@AutoConfigureMockMvc
@WithMockUser
public class LoanProductResourceIT {

    private static final Integer DEFAULT_QUANTITY = 0;
    private static final Integer UPDATED_QUANTITY = 1;

    private static final BigDecimal DEFAULT_TOTAL_PRICE = new BigDecimal(0);
    private static final BigDecimal UPDATED_TOTAL_PRICE = new BigDecimal(1);

    private static final LoanProductStatus DEFAULT_STATUS = LoanProductStatus.AVAILABLE;
    private static final LoanProductStatus UPDATED_STATUS = LoanProductStatus.EXIT_FROM_MARKET;

    @Autowired
    private LoanProductRepository loanProductRepository;

    @Autowired
    private LoanProductService loanProductService;

    @Autowired
    private EntityManager em;

    @Autowired
    private MockMvc restLoanProductMockMvc;

    private LoanProduct loanProduct;

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static LoanProduct createEntity(EntityManager em) {
        LoanProduct loanProduct = new LoanProduct()
            .quantity(DEFAULT_QUANTITY)
            .totalPrice(DEFAULT_TOTAL_PRICE)
            .status(DEFAULT_STATUS);
        // Add required entity
        Product product;
        if (TestUtil.findAll(em, Product.class).isEmpty()) {
            product = ProductResourceIT.createEntity(em);
            em.persist(product);
            em.flush();
        } else {
            product = TestUtil.findAll(em, Product.class).get(0);
        }
        loanProduct.setProduct(product);
        // Add required entity
        ProductPackage productPackage;
        if (TestUtil.findAll(em, ProductPackage.class).isEmpty()) {
            productPackage = ProductPackageResourceIT.createEntity(em);
            em.persist(productPackage);
            em.flush();
        } else {
            productPackage = TestUtil.findAll(em, ProductPackage.class).get(0);
        }
        loanProduct.setOrder(productPackage);
        return loanProduct;
    }
    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static LoanProduct createUpdatedEntity(EntityManager em) {
        LoanProduct loanProduct = new LoanProduct()
            .quantity(UPDATED_QUANTITY)
            .totalPrice(UPDATED_TOTAL_PRICE)
            .status(UPDATED_STATUS);
        // Add required entity
        Product product;
        if (TestUtil.findAll(em, Product.class).isEmpty()) {
            product = ProductResourceIT.createUpdatedEntity(em);
            em.persist(product);
            em.flush();
        } else {
            product = TestUtil.findAll(em, Product.class).get(0);
        }
        loanProduct.setProduct(product);
        // Add required entity
        ProductPackage productPackage;
        if (TestUtil.findAll(em, ProductPackage.class).isEmpty()) {
            productPackage = ProductPackageResourceIT.createUpdatedEntity(em);
            em.persist(productPackage);
            em.flush();
        } else {
            productPackage = TestUtil.findAll(em, ProductPackage.class).get(0);
        }
        loanProduct.setOrder(productPackage);
        return loanProduct;
    }

    @BeforeEach
    public void initTest() {
        loanProduct = createEntity(em);
    }

    @Test
    @Transactional
    public void createLoanProduct() throws Exception {
        int databaseSizeBeforeCreate = loanProductRepository.findAll().size();
        // Create the LoanProduct
        restLoanProductMockMvc.perform(post("/api/loan-products")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(loanProduct)))
            .andExpect(status().isCreated());

        // Validate the LoanProduct in the database
        List<LoanProduct> loanProductList = loanProductRepository.findAll();
        assertThat(loanProductList).hasSize(databaseSizeBeforeCreate + 1);
        LoanProduct testLoanProduct = loanProductList.get(loanProductList.size() - 1);
        assertThat(testLoanProduct.getQuantity()).isEqualTo(DEFAULT_QUANTITY);
        assertThat(testLoanProduct.getTotalPrice()).isEqualTo(DEFAULT_TOTAL_PRICE);
        assertThat(testLoanProduct.getStatus()).isEqualTo(DEFAULT_STATUS);
    }

    @Test
    @Transactional
    public void createLoanProductWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = loanProductRepository.findAll().size();

        // Create the LoanProduct with an existing ID
        loanProduct.setId(1L);

        // An entity with an existing ID cannot be created, so this API call must fail
        restLoanProductMockMvc.perform(post("/api/loan-products")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(loanProduct)))
            .andExpect(status().isBadRequest());

        // Validate the LoanProduct in the database
        List<LoanProduct> loanProductList = loanProductRepository.findAll();
        assertThat(loanProductList).hasSize(databaseSizeBeforeCreate);
    }


    @Test
    @Transactional
    public void checkQuantityIsRequired() throws Exception {
        int databaseSizeBeforeTest = loanProductRepository.findAll().size();
        // set the field null
        loanProduct.setQuantity(null);

        // Create the LoanProduct, which fails.


        restLoanProductMockMvc.perform(post("/api/loan-products")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(loanProduct)))
            .andExpect(status().isBadRequest());

        List<LoanProduct> loanProductList = loanProductRepository.findAll();
        assertThat(loanProductList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkTotalPriceIsRequired() throws Exception {
        int databaseSizeBeforeTest = loanProductRepository.findAll().size();
        // set the field null
        loanProduct.setTotalPrice(null);

        // Create the LoanProduct, which fails.


        restLoanProductMockMvc.perform(post("/api/loan-products")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(loanProduct)))
            .andExpect(status().isBadRequest());

        List<LoanProduct> loanProductList = loanProductRepository.findAll();
        assertThat(loanProductList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkStatusIsRequired() throws Exception {
        int databaseSizeBeforeTest = loanProductRepository.findAll().size();
        // set the field null
        loanProduct.setStatus(null);

        // Create the LoanProduct, which fails.


        restLoanProductMockMvc.perform(post("/api/loan-products")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(loanProduct)))
            .andExpect(status().isBadRequest());

        List<LoanProduct> loanProductList = loanProductRepository.findAll();
        assertThat(loanProductList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllLoanProducts() throws Exception {
        // Initialize the database
        loanProductRepository.saveAndFlush(loanProduct);

        // Get all the loanProductList
        restLoanProductMockMvc.perform(get("/api/loan-products?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(loanProduct.getId().intValue())))
            .andExpect(jsonPath("$.[*].quantity").value(hasItem(DEFAULT_QUANTITY)))
            .andExpect(jsonPath("$.[*].totalPrice").value(hasItem(DEFAULT_TOTAL_PRICE.intValue())))
            .andExpect(jsonPath("$.[*].status").value(hasItem(DEFAULT_STATUS.toString())));
    }
    
    @Test
    @Transactional
    public void getLoanProduct() throws Exception {
        // Initialize the database
        loanProductRepository.saveAndFlush(loanProduct);

        // Get the loanProduct
        restLoanProductMockMvc.perform(get("/api/loan-products/{id}", loanProduct.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.id").value(loanProduct.getId().intValue()))
            .andExpect(jsonPath("$.quantity").value(DEFAULT_QUANTITY))
            .andExpect(jsonPath("$.totalPrice").value(DEFAULT_TOTAL_PRICE.intValue()))
            .andExpect(jsonPath("$.status").value(DEFAULT_STATUS.toString()));
    }
    @Test
    @Transactional
    public void getNonExistingLoanProduct() throws Exception {
        // Get the loanProduct
        restLoanProductMockMvc.perform(get("/api/loan-products/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateLoanProduct() throws Exception {
        // Initialize the database
        loanProductService.save(loanProduct);

        int databaseSizeBeforeUpdate = loanProductRepository.findAll().size();

        // Update the loanProduct
        LoanProduct updatedLoanProduct = loanProductRepository.findById(loanProduct.getId()).get();
        // Disconnect from session so that the updates on updatedLoanProduct are not directly saved in db
        em.detach(updatedLoanProduct);
        updatedLoanProduct
            .quantity(UPDATED_QUANTITY)
            .totalPrice(UPDATED_TOTAL_PRICE)
            .status(UPDATED_STATUS);

        restLoanProductMockMvc.perform(put("/api/loan-products")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(updatedLoanProduct)))
            .andExpect(status().isOk());

        // Validate the LoanProduct in the database
        List<LoanProduct> loanProductList = loanProductRepository.findAll();
        assertThat(loanProductList).hasSize(databaseSizeBeforeUpdate);
        LoanProduct testLoanProduct = loanProductList.get(loanProductList.size() - 1);
        assertThat(testLoanProduct.getQuantity()).isEqualTo(UPDATED_QUANTITY);
        assertThat(testLoanProduct.getTotalPrice()).isEqualTo(UPDATED_TOTAL_PRICE);
        assertThat(testLoanProduct.getStatus()).isEqualTo(UPDATED_STATUS);
    }

    @Test
    @Transactional
    public void updateNonExistingLoanProduct() throws Exception {
        int databaseSizeBeforeUpdate = loanProductRepository.findAll().size();

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restLoanProductMockMvc.perform(put("/api/loan-products")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(loanProduct)))
            .andExpect(status().isBadRequest());

        // Validate the LoanProduct in the database
        List<LoanProduct> loanProductList = loanProductRepository.findAll();
        assertThat(loanProductList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    public void deleteLoanProduct() throws Exception {
        // Initialize the database
        loanProductService.save(loanProduct);

        int databaseSizeBeforeDelete = loanProductRepository.findAll().size();

        // Delete the loanProduct
        restLoanProductMockMvc.perform(delete("/api/loan-products/{id}", loanProduct.getId())
            .accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<LoanProduct> loanProductList = loanProductRepository.findAll();
        assertThat(loanProductList).hasSize(databaseSizeBeforeDelete - 1);
    }
}
