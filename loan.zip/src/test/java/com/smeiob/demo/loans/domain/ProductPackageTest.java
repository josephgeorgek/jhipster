package com.smeiob.demo.loans.domain;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;
import com.smeiob.demo.loans.web.rest.TestUtil;

public class ProductPackageTest {

    @Test
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(ProductPackage.class);
        ProductPackage productPackage1 = new ProductPackage();
        productPackage1.setId(1L);
        ProductPackage productPackage2 = new ProductPackage();
        productPackage2.setId(productPackage1.getId());
        assertThat(productPackage1).isEqualTo(productPackage2);
        productPackage2.setId(2L);
        assertThat(productPackage1).isNotEqualTo(productPackage2);
        productPackage1.setId(null);
        assertThat(productPackage1).isNotEqualTo(productPackage2);
    }
}
