import { browser, element, by } from 'protractor';

import NavBarPage from './../../../page-objects/navbar-page';
import SignInPage from './../../../page-objects/signin-page';
import LoanApplicationComponentsPage from './loan-application.page-object';
import LoanApplicationUpdatePage from './loan-application-update.page-object';
import {
  waitUntilDisplayed,
  waitUntilAnyDisplayed,
  click,
  getRecordsCount,
  waitUntilHidden,
  waitUntilCount,
  isVisible,
} from '../../../util/utils';

const expect = chai.expect;

describe('LoanApplication e2e test', () => {
  let navBarPage: NavBarPage;
  let signInPage: SignInPage;
  let loanApplicationComponentsPage: LoanApplicationComponentsPage;
  let loanApplicationUpdatePage: LoanApplicationUpdatePage;

  before(async () => {
    await browser.get('/');
    navBarPage = new NavBarPage();
    signInPage = await navBarPage.getSignInPage();
    await signInPage.waitUntilDisplayed();

    await signInPage.username.sendKeys('admin');
    await signInPage.password.sendKeys('admin');
    await signInPage.loginButton.click();
    await signInPage.waitUntilHidden();
    await waitUntilDisplayed(navBarPage.entityMenu);
    await waitUntilDisplayed(navBarPage.adminMenu);
    await waitUntilDisplayed(navBarPage.accountMenu);
  });

  beforeEach(async () => {
    await browser.get('/');
    await waitUntilDisplayed(navBarPage.entityMenu);
    loanApplicationComponentsPage = new LoanApplicationComponentsPage();
    loanApplicationComponentsPage = await loanApplicationComponentsPage.goToPage(navBarPage);
  });

  it('should load LoanApplications', async () => {
    expect(await loanApplicationComponentsPage.title.getText()).to.match(/Loan Applications/);
    expect(await loanApplicationComponentsPage.createButton.isEnabled()).to.be.true;
  });

  it('should create and delete LoanApplications', async () => {
    const beforeRecordsCount = (await isVisible(loanApplicationComponentsPage.noRecords))
      ? 0
      : await getRecordsCount(loanApplicationComponentsPage.table);
    loanApplicationUpdatePage = await loanApplicationComponentsPage.goToCreateLoanApplication();
    await loanApplicationUpdatePage.enterData();

    expect(await loanApplicationComponentsPage.createButton.isEnabled()).to.be.true;
    await waitUntilDisplayed(loanApplicationComponentsPage.table);
    await waitUntilCount(loanApplicationComponentsPage.records, beforeRecordsCount + 1);
    expect(await loanApplicationComponentsPage.records.count()).to.eq(beforeRecordsCount + 1);

    await loanApplicationComponentsPage.deleteLoanApplication();
    if (beforeRecordsCount !== 0) {
      await waitUntilCount(loanApplicationComponentsPage.records, beforeRecordsCount);
      expect(await loanApplicationComponentsPage.records.count()).to.eq(beforeRecordsCount);
    } else {
      await waitUntilDisplayed(loanApplicationComponentsPage.noRecords);
    }
  });

  after(async () => {
    await navBarPage.autoSignOut();
  });
});
