package com.smeiob.demo.loans.service;

import com.smeiob.demo.loans.domain.ProductPackage;
import com.smeiob.demo.loans.repository.ProductPackageRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

/**
 * Service Implementation for managing {@link ProductPackage}.
 */
@Service
@Transactional
public class ProductPackageService {

    private final Logger log = LoggerFactory.getLogger(ProductPackageService.class);

    private final ProductPackageRepository productPackageRepository;

    public ProductPackageService(ProductPackageRepository productPackageRepository) {
        this.productPackageRepository = productPackageRepository;
    }

    /**
     * Save a productPackage.
     *
     * @param productPackage the entity to save.
     * @return the persisted entity.
     */
    public ProductPackage save(ProductPackage productPackage) {
        log.debug("Request to save ProductPackage : {}", productPackage);
        return productPackageRepository.save(productPackage);
    }

    /**
     * Get all the productPackages.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    @Transactional(readOnly = true)
    public Page<ProductPackage> findAll(Pageable pageable) {
        log.debug("Request to get all ProductPackages");
        return productPackageRepository.findAll(pageable);
    }


    /**
     * Get one productPackage by id.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    @Transactional(readOnly = true)
    public Optional<ProductPackage> findOne(Long id) {
        log.debug("Request to get ProductPackage : {}", id);
        return productPackageRepository.findById(id);
    }

    /**
     * Delete the productPackage by id.
     *
     * @param id the id of the entity.
     */
    public void delete(Long id) {
        log.debug("Request to delete ProductPackage : {}", id);
        productPackageRepository.deleteById(id);
    }
}
