package com.smeiob.demo.loans.domain.enumeration;

/**
 * The ApplicationStatus enumeration.
 */
public enum ApplicationStatus {
    DRAFT, COMPLETED, PENDING, CANCELLED
}
