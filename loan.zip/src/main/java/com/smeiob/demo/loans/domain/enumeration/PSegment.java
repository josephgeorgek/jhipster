package com.smeiob.demo.loans.domain.enumeration;

/**
 * The PSegment enumeration.
 */
public enum PSegment {
    PPC, SME_S, SME_L, XL, XXL
}
