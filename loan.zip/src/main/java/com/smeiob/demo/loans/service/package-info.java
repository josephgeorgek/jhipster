/**
 * Service layer beans.
 */
package com.smeiob.demo.loans.service;
