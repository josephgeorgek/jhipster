package com.smeiob.demo.loans.web.rest;

import com.smeiob.demo.loans.domain.LoanProduct;
import com.smeiob.demo.loans.service.LoanProductService;
import com.smeiob.demo.loans.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.PaginationUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing {@link com.smeiob.demo.loans.domain.LoanProduct}.
 */
@RestController
@RequestMapping("/api")
public class LoanProductResource {

    private final Logger log = LoggerFactory.getLogger(LoanProductResource.class);

    private static final String ENTITY_NAME = "loanProduct";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final LoanProductService loanProductService;

    public LoanProductResource(LoanProductService loanProductService) {
        this.loanProductService = loanProductService;
    }

    /**
     * {@code POST  /loan-products} : Create a new loanProduct.
     *
     * @param loanProduct the loanProduct to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new loanProduct, or with status {@code 400 (Bad Request)} if the loanProduct has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/loan-products")
    public ResponseEntity<LoanProduct> createLoanProduct(@Valid @RequestBody LoanProduct loanProduct) throws URISyntaxException {
        log.debug("REST request to save LoanProduct : {}", loanProduct);
        if (loanProduct.getId() != null) {
            throw new BadRequestAlertException("A new loanProduct cannot already have an ID", ENTITY_NAME, "idexists");
        }
        LoanProduct result = loanProductService.save(loanProduct);
        return ResponseEntity.created(new URI("/api/loan-products/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /loan-products} : Updates an existing loanProduct.
     *
     * @param loanProduct the loanProduct to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated loanProduct,
     * or with status {@code 400 (Bad Request)} if the loanProduct is not valid,
     * or with status {@code 500 (Internal Server Error)} if the loanProduct couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/loan-products")
    public ResponseEntity<LoanProduct> updateLoanProduct(@Valid @RequestBody LoanProduct loanProduct) throws URISyntaxException {
        log.debug("REST request to update LoanProduct : {}", loanProduct);
        if (loanProduct.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        LoanProduct result = loanProductService.save(loanProduct);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, loanProduct.getId().toString()))
            .body(result);
    }

    /**
     * {@code GET  /loan-products} : get all the loanProducts.
     *
     * @param pageable the pagination information.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of loanProducts in body.
     */
    @GetMapping("/loan-products")
    public ResponseEntity<List<LoanProduct>> getAllLoanProducts(Pageable pageable) {
        log.debug("REST request to get a page of LoanProducts");
        Page<LoanProduct> page = loanProductService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(ServletUriComponentsBuilder.fromCurrentRequest(), page);
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * {@code GET  /loan-products/:id} : get the "id" loanProduct.
     *
     * @param id the id of the loanProduct to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the loanProduct, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/loan-products/{id}")
    public ResponseEntity<LoanProduct> getLoanProduct(@PathVariable Long id) {
        log.debug("REST request to get LoanProduct : {}", id);
        Optional<LoanProduct> loanProduct = loanProductService.findOne(id);
        return ResponseUtil.wrapOrNotFound(loanProduct);
    }

    /**
     * {@code DELETE  /loan-products/:id} : delete the "id" loanProduct.
     *
     * @param id the id of the loanProduct to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/loan-products/{id}")
    public ResponseEntity<Void> deleteLoanProduct(@PathVariable Long id) {
        log.debug("REST request to delete LoanProduct : {}", id);
        loanProductService.delete(id);
        return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString())).build();
    }
}
