/**
 * Spring MVC REST controllers.
 */
package com.smeiob.demo.loans.web.rest;
