/**
 * Audit specific code.
 */
package com.smeiob.demo.loans.config.audit;
