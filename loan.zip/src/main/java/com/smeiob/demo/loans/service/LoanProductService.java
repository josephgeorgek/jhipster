package com.smeiob.demo.loans.service;

import com.smeiob.demo.loans.domain.LoanProduct;
import com.smeiob.demo.loans.repository.LoanProductRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

/**
 * Service Implementation for managing {@link LoanProduct}.
 */
@Service
@Transactional
public class LoanProductService {

    private final Logger log = LoggerFactory.getLogger(LoanProductService.class);

    private final LoanProductRepository loanProductRepository;

    public LoanProductService(LoanProductRepository loanProductRepository) {
        this.loanProductRepository = loanProductRepository;
    }

    /**
     * Save a loanProduct.
     *
     * @param loanProduct the entity to save.
     * @return the persisted entity.
     */
    public LoanProduct save(LoanProduct loanProduct) {
        log.debug("Request to save LoanProduct : {}", loanProduct);
        return loanProductRepository.save(loanProduct);
    }

    /**
     * Get all the loanProducts.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    @Transactional(readOnly = true)
    public Page<LoanProduct> findAll(Pageable pageable) {
        log.debug("Request to get all LoanProducts");
        return loanProductRepository.findAll(pageable);
    }


    /**
     * Get one loanProduct by id.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    @Transactional(readOnly = true)
    public Optional<LoanProduct> findOne(Long id) {
        log.debug("Request to get LoanProduct : {}", id);
        return loanProductRepository.findById(id);
    }

    /**
     * Delete the loanProduct by id.
     *
     * @param id the id of the entity.
     */
    public void delete(Long id) {
        log.debug("Request to delete LoanProduct : {}", id);
        loanProductRepository.deleteById(id);
    }
}
