package com.smeiob.demo.loans.domain.enumeration;

/**
 * The LoanProductStatus enumeration.
 */
public enum LoanProductStatus {
    AVAILABLE, EXIT_FROM_MARKET, ON_PROMOTION_ONLY
}
