/**
 * Spring Security configuration.
 */
package com.smeiob.demo.loans.security;
