/**
 * Data Transfer Objects.
 */
package com.smeiob.demo.loans.service.dto;
