/**
 * MapStruct mappers for mapping domain objects and Data Transfer Objects.
 */
package com.smeiob.demo.loans.service.mapper;
