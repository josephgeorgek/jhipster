package com.smeiob.demo.loans.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.time.Instant;
import java.util.HashSet;
import java.util.Set;

import com.smeiob.demo.loans.domain.enumeration.ApplicationStatus;

/**
 * A ProductPackage.
 */
@Entity
@Table(name = "product_package")
public class ProductPackage implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @Column(name = "placed_date", nullable = false)
    private Instant placedDate;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private ApplicationStatus status;

    @NotNull
    @Column(name = "code", nullable = false)
    private String code;

    @Column(name = "facility_id")
    private Long facilityId;

    @OneToMany(mappedBy = "order")
    private Set<LoanProduct> orderItems = new HashSet<>();

    @ManyToOne(optional = false)
    @NotNull
    @JsonIgnoreProperties(value = "orders", allowSetters = true)
    private Customer customer;

    // jhipster-needle-entity-add-field - JHipster will add fields here
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Instant getPlacedDate() {
        return placedDate;
    }

    public ProductPackage placedDate(Instant placedDate) {
        this.placedDate = placedDate;
        return this;
    }

    public void setPlacedDate(Instant placedDate) {
        this.placedDate = placedDate;
    }

    public ApplicationStatus getStatus() {
        return status;
    }

    public ProductPackage status(ApplicationStatus status) {
        this.status = status;
        return this;
    }

    public void setStatus(ApplicationStatus status) {
        this.status = status;
    }

    public String getCode() {
        return code;
    }

    public ProductPackage code(String code) {
        this.code = code;
        return this;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Long getFacilityId() {
        return facilityId;
    }

    public ProductPackage facilityId(Long facilityId) {
        this.facilityId = facilityId;
        return this;
    }

    public void setFacilityId(Long facilityId) {
        this.facilityId = facilityId;
    }

    public Set<LoanProduct> getOrderItems() {
        return orderItems;
    }

    public ProductPackage orderItems(Set<LoanProduct> loanProducts) {
        this.orderItems = loanProducts;
        return this;
    }

    public ProductPackage addOrderItem(LoanProduct loanProduct) {
        this.orderItems.add(loanProduct);
        loanProduct.setOrder(this);
        return this;
    }

    public ProductPackage removeOrderItem(LoanProduct loanProduct) {
        this.orderItems.remove(loanProduct);
        loanProduct.setOrder(null);
        return this;
    }

    public void setOrderItems(Set<LoanProduct> loanProducts) {
        this.orderItems = loanProducts;
    }

    public Customer getCustomer() {
        return customer;
    }

    public ProductPackage customer(Customer customer) {
        this.customer = customer;
        return this;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof ProductPackage)) {
            return false;
        }
        return id != null && id.equals(((ProductPackage) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "ProductPackage{" +
            "id=" + getId() +
            ", placedDate='" + getPlacedDate() + "'" +
            ", status='" + getStatus() + "'" +
            ", code='" + getCode() + "'" +
            ", facilityId=" + getFacilityId() +
            "}";
    }
}
