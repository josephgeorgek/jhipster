package com.smeiob.demo.loans.web.rest;

import com.smeiob.demo.loans.domain.ProductPackage;
import com.smeiob.demo.loans.service.ProductPackageService;
import com.smeiob.demo.loans.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.PaginationUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing {@link com.smeiob.demo.loans.domain.ProductPackage}.
 */
@RestController
@RequestMapping("/api")
public class ProductPackageResource {

    private final Logger log = LoggerFactory.getLogger(ProductPackageResource.class);

    private static final String ENTITY_NAME = "productPackage";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final ProductPackageService productPackageService;

    public ProductPackageResource(ProductPackageService productPackageService) {
        this.productPackageService = productPackageService;
    }

    /**
     * {@code POST  /product-packages} : Create a new productPackage.
     *
     * @param productPackage the productPackage to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new productPackage, or with status {@code 400 (Bad Request)} if the productPackage has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/product-packages")
    public ResponseEntity<ProductPackage> createProductPackage(@Valid @RequestBody ProductPackage productPackage) throws URISyntaxException {
        log.debug("REST request to save ProductPackage : {}", productPackage);
        if (productPackage.getId() != null) {
            throw new BadRequestAlertException("A new productPackage cannot already have an ID", ENTITY_NAME, "idexists");
        }
        ProductPackage result = productPackageService.save(productPackage);
        return ResponseEntity.created(new URI("/api/product-packages/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /product-packages} : Updates an existing productPackage.
     *
     * @param productPackage the productPackage to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated productPackage,
     * or with status {@code 400 (Bad Request)} if the productPackage is not valid,
     * or with status {@code 500 (Internal Server Error)} if the productPackage couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/product-packages")
    public ResponseEntity<ProductPackage> updateProductPackage(@Valid @RequestBody ProductPackage productPackage) throws URISyntaxException {
        log.debug("REST request to update ProductPackage : {}", productPackage);
        if (productPackage.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        ProductPackage result = productPackageService.save(productPackage);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, productPackage.getId().toString()))
            .body(result);
    }

    /**
     * {@code GET  /product-packages} : get all the productPackages.
     *
     * @param pageable the pagination information.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of productPackages in body.
     */
    @GetMapping("/product-packages")
    public ResponseEntity<List<ProductPackage>> getAllProductPackages(Pageable pageable) {
        log.debug("REST request to get a page of ProductPackages");
        Page<ProductPackage> page = productPackageService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(ServletUriComponentsBuilder.fromCurrentRequest(), page);
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * {@code GET  /product-packages/:id} : get the "id" productPackage.
     *
     * @param id the id of the productPackage to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the productPackage, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/product-packages/{id}")
    public ResponseEntity<ProductPackage> getProductPackage(@PathVariable Long id) {
        log.debug("REST request to get ProductPackage : {}", id);
        Optional<ProductPackage> productPackage = productPackageService.findOne(id);
        return ResponseUtil.wrapOrNotFound(productPackage);
    }

    /**
     * {@code DELETE  /product-packages/:id} : delete the "id" productPackage.
     *
     * @param id the id of the productPackage to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/product-packages/{id}")
    public ResponseEntity<Void> deleteProductPackage(@PathVariable Long id) {
        log.debug("REST request to delete ProductPackage : {}", id);
        productPackageService.delete(id);
        return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString())).build();
    }
}
