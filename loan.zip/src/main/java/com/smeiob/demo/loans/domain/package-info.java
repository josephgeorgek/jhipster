/**
 * JPA domain objects.
 */
package com.smeiob.demo.loans.domain;
