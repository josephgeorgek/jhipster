export const enum LoanApplicationStatus {
  APPROVED = 'APPROVED',

  PAID = 'PAID',

  ISSUED = 'ISSUED',

  CANCELLED = 'CANCELLED',
}
