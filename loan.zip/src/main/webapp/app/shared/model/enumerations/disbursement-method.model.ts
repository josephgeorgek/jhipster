export const enum DisbursementMethod {
  OD = 'OD',

  ACCOUNT = 'ACCOUNT',

  GIRO = 'GIRO',
}
