import { Moment } from 'moment';
import { IDisbursement } from 'app/shared/model/loanApplication/disbursement.model';
import { LoanApplicationStatus } from 'app/shared/model/enumerations/loan-application-status.model';
import { DisbursementMethod } from 'app/shared/model/enumerations/disbursement-method.model';

export interface ILoanApplication {
  id?: number;
  code?: string;
  date?: string;
  details?: string;
  status?: LoanApplicationStatus;
  paymentMethod?: DisbursementMethod;
  disburementDate?: string;
  amount?: number;
  shipments?: IDisbursement[];
}

export const defaultValue: Readonly<ILoanApplication> = {};
