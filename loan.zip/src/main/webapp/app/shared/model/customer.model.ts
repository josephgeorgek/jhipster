import { IUser } from 'app/shared/model/user.model';
import { IProductPackage } from 'app/shared/model/product-package.model';
import { Gender } from 'app/shared/model/enumerations/gender.model';

export interface ICustomer {
  id?: number;
  firstName?: string;
  lastName?: string;
  gender?: Gender;
  email?: string;
  phone?: string;
  addressLine1?: string;
  addressLine2?: string;
  city?: string;
  country?: string;
  user?: IUser;
  orders?: IProductPackage[];
}

export const defaultValue: Readonly<ICustomer> = {};
