import axios from 'axios';
import { ICrudGetAction, ICrudGetAllAction, ICrudPutAction, ICrudDeleteAction } from 'react-jhipster';

import { cleanEntity } from 'app/shared/util/entity-utils';
import { REQUEST, SUCCESS, FAILURE } from 'app/shared/reducers/action-type.util';

import { ILoanApplication, defaultValue } from 'app/shared/model/loanApplication/loan-application.model';

export const ACTION_TYPES = {
  FETCH_LOANAPPLICATION_LIST: 'loanApplication/FETCH_LOANAPPLICATION_LIST',
  FETCH_LOANAPPLICATION: 'loanApplication/FETCH_LOANAPPLICATION',
  CREATE_LOANAPPLICATION: 'loanApplication/CREATE_LOANAPPLICATION',
  UPDATE_LOANAPPLICATION: 'loanApplication/UPDATE_LOANAPPLICATION',
  DELETE_LOANAPPLICATION: 'loanApplication/DELETE_LOANAPPLICATION',
  RESET: 'loanApplication/RESET',
};

const initialState = {
  loading: false,
  errorMessage: null,
  entities: [] as ReadonlyArray<ILoanApplication>,
  entity: defaultValue,
  updating: false,
  totalItems: 0,
  updateSuccess: false,
};

export type LoanApplicationState = Readonly<typeof initialState>;

// Reducer

export default (state: LoanApplicationState = initialState, action): LoanApplicationState => {
  switch (action.type) {
    case REQUEST(ACTION_TYPES.FETCH_LOANAPPLICATION_LIST):
    case REQUEST(ACTION_TYPES.FETCH_LOANAPPLICATION):
      return {
        ...state,
        errorMessage: null,
        updateSuccess: false,
        loading: true,
      };
    case REQUEST(ACTION_TYPES.CREATE_LOANAPPLICATION):
    case REQUEST(ACTION_TYPES.UPDATE_LOANAPPLICATION):
    case REQUEST(ACTION_TYPES.DELETE_LOANAPPLICATION):
      return {
        ...state,
        errorMessage: null,
        updateSuccess: false,
        updating: true,
      };
    case FAILURE(ACTION_TYPES.FETCH_LOANAPPLICATION_LIST):
    case FAILURE(ACTION_TYPES.FETCH_LOANAPPLICATION):
    case FAILURE(ACTION_TYPES.CREATE_LOANAPPLICATION):
    case FAILURE(ACTION_TYPES.UPDATE_LOANAPPLICATION):
    case FAILURE(ACTION_TYPES.DELETE_LOANAPPLICATION):
      return {
        ...state,
        loading: false,
        updating: false,
        updateSuccess: false,
        errorMessage: action.payload,
      };
    case SUCCESS(ACTION_TYPES.FETCH_LOANAPPLICATION_LIST):
      return {
        ...state,
        loading: false,
        entities: action.payload.data,
        totalItems: parseInt(action.payload.headers['x-total-count'], 10),
      };
    case SUCCESS(ACTION_TYPES.FETCH_LOANAPPLICATION):
      return {
        ...state,
        loading: false,
        entity: action.payload.data,
      };
    case SUCCESS(ACTION_TYPES.CREATE_LOANAPPLICATION):
    case SUCCESS(ACTION_TYPES.UPDATE_LOANAPPLICATION):
      return {
        ...state,
        updating: false,
        updateSuccess: true,
        entity: action.payload.data,
      };
    case SUCCESS(ACTION_TYPES.DELETE_LOANAPPLICATION):
      return {
        ...state,
        updating: false,
        updateSuccess: true,
        entity: {},
      };
    case ACTION_TYPES.RESET:
      return {
        ...initialState,
      };
    default:
      return state;
  }
};

const apiUrl = 'services/loanapplication/api/loan-applications';

// Actions

export const getEntities: ICrudGetAllAction<ILoanApplication> = (page, size, sort) => {
  const requestUrl = `${apiUrl}${sort ? `?page=${page}&size=${size}&sort=${sort}` : ''}`;
  return {
    type: ACTION_TYPES.FETCH_LOANAPPLICATION_LIST,
    payload: axios.get<ILoanApplication>(`${requestUrl}${sort ? '&' : '?'}cacheBuster=${new Date().getTime()}`),
  };
};

export const getEntity: ICrudGetAction<ILoanApplication> = id => {
  const requestUrl = `${apiUrl}/${id}`;
  return {
    type: ACTION_TYPES.FETCH_LOANAPPLICATION,
    payload: axios.get<ILoanApplication>(requestUrl),
  };
};

export const createEntity: ICrudPutAction<ILoanApplication> = entity => async dispatch => {
  const result = await dispatch({
    type: ACTION_TYPES.CREATE_LOANAPPLICATION,
    payload: axios.post(apiUrl, cleanEntity(entity)),
  });
  dispatch(getEntities());
  return result;
};

export const updateEntity: ICrudPutAction<ILoanApplication> = entity => async dispatch => {
  const result = await dispatch({
    type: ACTION_TYPES.UPDATE_LOANAPPLICATION,
    payload: axios.put(apiUrl, cleanEntity(entity)),
  });
  return result;
};

export const deleteEntity: ICrudDeleteAction<ILoanApplication> = id => async dispatch => {
  const requestUrl = `${apiUrl}/${id}`;
  const result = await dispatch({
    type: ACTION_TYPES.DELETE_LOANAPPLICATION,
    payload: axios.delete(requestUrl),
  });
  dispatch(getEntities());
  return result;
};

export const reset = () => ({
  type: ACTION_TYPES.RESET,
});
