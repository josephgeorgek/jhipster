import axios from 'axios';
import { ICrudGetAction, ICrudGetAllAction, ICrudPutAction, ICrudDeleteAction } from 'react-jhipster';

import { cleanEntity } from 'app/shared/util/entity-utils';
import { REQUEST, SUCCESS, FAILURE } from 'app/shared/reducers/action-type.util';

import { IProductPackage, defaultValue } from 'app/shared/model/product-package.model';

export const ACTION_TYPES = {
  FETCH_PRODUCTPACKAGE_LIST: 'productPackage/FETCH_PRODUCTPACKAGE_LIST',
  FETCH_PRODUCTPACKAGE: 'productPackage/FETCH_PRODUCTPACKAGE',
  CREATE_PRODUCTPACKAGE: 'productPackage/CREATE_PRODUCTPACKAGE',
  UPDATE_PRODUCTPACKAGE: 'productPackage/UPDATE_PRODUCTPACKAGE',
  DELETE_PRODUCTPACKAGE: 'productPackage/DELETE_PRODUCTPACKAGE',
  RESET: 'productPackage/RESET',
};

const initialState = {
  loading: false,
  errorMessage: null,
  entities: [] as ReadonlyArray<IProductPackage>,
  entity: defaultValue,
  updating: false,
  totalItems: 0,
  updateSuccess: false,
};

export type ProductPackageState = Readonly<typeof initialState>;

// Reducer

export default (state: ProductPackageState = initialState, action): ProductPackageState => {
  switch (action.type) {
    case REQUEST(ACTION_TYPES.FETCH_PRODUCTPACKAGE_LIST):
    case REQUEST(ACTION_TYPES.FETCH_PRODUCTPACKAGE):
      return {
        ...state,
        errorMessage: null,
        updateSuccess: false,
        loading: true,
      };
    case REQUEST(ACTION_TYPES.CREATE_PRODUCTPACKAGE):
    case REQUEST(ACTION_TYPES.UPDATE_PRODUCTPACKAGE):
    case REQUEST(ACTION_TYPES.DELETE_PRODUCTPACKAGE):
      return {
        ...state,
        errorMessage: null,
        updateSuccess: false,
        updating: true,
      };
    case FAILURE(ACTION_TYPES.FETCH_PRODUCTPACKAGE_LIST):
    case FAILURE(ACTION_TYPES.FETCH_PRODUCTPACKAGE):
    case FAILURE(ACTION_TYPES.CREATE_PRODUCTPACKAGE):
    case FAILURE(ACTION_TYPES.UPDATE_PRODUCTPACKAGE):
    case FAILURE(ACTION_TYPES.DELETE_PRODUCTPACKAGE):
      return {
        ...state,
        loading: false,
        updating: false,
        updateSuccess: false,
        errorMessage: action.payload,
      };
    case SUCCESS(ACTION_TYPES.FETCH_PRODUCTPACKAGE_LIST):
      return {
        ...state,
        loading: false,
        entities: action.payload.data,
        totalItems: parseInt(action.payload.headers['x-total-count'], 10),
      };
    case SUCCESS(ACTION_TYPES.FETCH_PRODUCTPACKAGE):
      return {
        ...state,
        loading: false,
        entity: action.payload.data,
      };
    case SUCCESS(ACTION_TYPES.CREATE_PRODUCTPACKAGE):
    case SUCCESS(ACTION_TYPES.UPDATE_PRODUCTPACKAGE):
      return {
        ...state,
        updating: false,
        updateSuccess: true,
        entity: action.payload.data,
      };
    case SUCCESS(ACTION_TYPES.DELETE_PRODUCTPACKAGE):
      return {
        ...state,
        updating: false,
        updateSuccess: true,
        entity: {},
      };
    case ACTION_TYPES.RESET:
      return {
        ...initialState,
      };
    default:
      return state;
  }
};

const apiUrl = 'api/product-packages';

// Actions

export const getEntities: ICrudGetAllAction<IProductPackage> = (page, size, sort) => {
  const requestUrl = `${apiUrl}${sort ? `?page=${page}&size=${size}&sort=${sort}` : ''}`;
  return {
    type: ACTION_TYPES.FETCH_PRODUCTPACKAGE_LIST,
    payload: axios.get<IProductPackage>(`${requestUrl}${sort ? '&' : '?'}cacheBuster=${new Date().getTime()}`),
  };
};

export const getEntity: ICrudGetAction<IProductPackage> = id => {
  const requestUrl = `${apiUrl}/${id}`;
  return {
    type: ACTION_TYPES.FETCH_PRODUCTPACKAGE,
    payload: axios.get<IProductPackage>(requestUrl),
  };
};

export const createEntity: ICrudPutAction<IProductPackage> = entity => async dispatch => {
  const result = await dispatch({
    type: ACTION_TYPES.CREATE_PRODUCTPACKAGE,
    payload: axios.post(apiUrl, cleanEntity(entity)),
  });
  dispatch(getEntities());
  return result;
};

export const updateEntity: ICrudPutAction<IProductPackage> = entity => async dispatch => {
  const result = await dispatch({
    type: ACTION_TYPES.UPDATE_PRODUCTPACKAGE,
    payload: axios.put(apiUrl, cleanEntity(entity)),
  });
  return result;
};

export const deleteEntity: ICrudDeleteAction<IProductPackage> = id => async dispatch => {
  const requestUrl = `${apiUrl}/${id}`;
  const result = await dispatch({
    type: ACTION_TYPES.DELETE_PRODUCTPACKAGE,
    payload: axios.delete(requestUrl),
  });
  dispatch(getEntities());
  return result;
};

export const reset = () => ({
  type: ACTION_TYPES.RESET,
});
