import React, { useState, useEffect } from 'react';
import { connect } from 'react-redux';
import { Link, RouteComponentProps } from 'react-router-dom';
import { Button, Row, Col, Label } from 'reactstrap';
import { AvFeedback, AvForm, AvGroup, AvInput, AvField } from 'availity-reactstrap-validation';
import { Translate, translate, ICrudGetAction, ICrudGetAllAction, ICrudPutAction } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { IRootState } from 'app/shared/reducers';

import { ICustomer } from 'app/shared/model/customer.model';
import { getEntities as getCustomers } from 'app/entities/customer/customer.reducer';
import { getEntity, updateEntity, createEntity, reset } from './product-package.reducer';
import { IProductPackage } from 'app/shared/model/product-package.model';
import { convertDateTimeFromServer, convertDateTimeToServer, displayDefaultDateTime } from 'app/shared/util/date-utils';
import { mapIdList } from 'app/shared/util/entity-utils';

export interface IProductPackageUpdateProps extends StateProps, DispatchProps, RouteComponentProps<{ id: string }> {}

export const ProductPackageUpdate = (props: IProductPackageUpdateProps) => {
  const [customerId, setCustomerId] = useState('0');
  const [isNew, setIsNew] = useState(!props.match.params || !props.match.params.id);

  const { productPackageEntity, customers, loading, updating } = props;

  const handleClose = () => {
    props.history.push('/product-package' + props.location.search);
  };

  useEffect(() => {
    if (isNew) {
      props.reset();
    } else {
      props.getEntity(props.match.params.id);
    }

    props.getCustomers();
  }, []);

  useEffect(() => {
    if (props.updateSuccess) {
      handleClose();
    }
  }, [props.updateSuccess]);

  const saveEntity = (event, errors, values) => {
    values.placedDate = convertDateTimeToServer(values.placedDate);

    if (errors.length === 0) {
      const entity = {
        ...productPackageEntity,
        ...values,
      };

      if (isNew) {
        props.createEntity(entity);
      } else {
        props.updateEntity(entity);
      }
    }
  };

  return (
    <div>
      <Row className="justify-content-center">
        <Col md="8">
          <h2 id="loansApp.productPackage.home.createOrEditLabel">
            <Translate contentKey="loansApp.productPackage.home.createOrEditLabel">Create or edit a ProductPackage</Translate>
          </h2>
        </Col>
      </Row>
      <Row className="justify-content-center">
        <Col md="8">
          {loading ? (
            <p>Loading...</p>
          ) : (
            <AvForm model={isNew ? {} : productPackageEntity} onSubmit={saveEntity}>
              {!isNew ? (
                <AvGroup>
                  <Label for="product-package-id">
                    <Translate contentKey="global.field.id">ID</Translate>
                  </Label>
                  <AvInput id="product-package-id" type="text" className="form-control" name="id" required readOnly />
                </AvGroup>
              ) : null}
              <AvGroup>
                <Label id="placedDateLabel" for="product-package-placedDate">
                  <Translate contentKey="loansApp.productPackage.placedDate">Placed Date</Translate>
                </Label>
                <AvInput
                  id="product-package-placedDate"
                  type="datetime-local"
                  className="form-control"
                  name="placedDate"
                  placeholder={'YYYY-MM-DD HH:mm'}
                  value={isNew ? displayDefaultDateTime() : convertDateTimeFromServer(props.productPackageEntity.placedDate)}
                  validate={{
                    required: { value: true, errorMessage: translate('entity.validation.required') },
                  }}
                />
              </AvGroup>
              <AvGroup>
                <Label id="statusLabel" for="product-package-status">
                  <Translate contentKey="loansApp.productPackage.status">Status</Translate>
                </Label>
                <AvInput
                  id="product-package-status"
                  type="select"
                  className="form-control"
                  name="status"
                  value={(!isNew && productPackageEntity.status) || 'DRAFT'}
                >
                  <option value="DRAFT">{translate('loansApp.ApplicationStatus.DRAFT')}</option>
                  <option value="COMPLETED">{translate('loansApp.ApplicationStatus.COMPLETED')}</option>
                  <option value="PENDING">{translate('loansApp.ApplicationStatus.PENDING')}</option>
                  <option value="CANCELLED">{translate('loansApp.ApplicationStatus.CANCELLED')}</option>
                </AvInput>
              </AvGroup>
              <AvGroup>
                <Label id="codeLabel" for="product-package-code">
                  <Translate contentKey="loansApp.productPackage.code">Code</Translate>
                </Label>
                <AvField
                  id="product-package-code"
                  type="text"
                  name="code"
                  validate={{
                    required: { value: true, errorMessage: translate('entity.validation.required') },
                  }}
                />
              </AvGroup>
              <AvGroup>
                <Label id="facilityIdLabel" for="product-package-facilityId">
                  <Translate contentKey="loansApp.productPackage.facilityId">Facility Id</Translate>
                </Label>
                <AvField id="product-package-facilityId" type="string" className="form-control" name="facilityId" />
              </AvGroup>
              <AvGroup>
                <Label for="product-package-customer">
                  <Translate contentKey="loansApp.productPackage.customer">Customer</Translate>
                </Label>
                <AvInput
                  id="product-package-customer"
                  type="select"
                  className="form-control"
                  name="customer.id"
                  value={isNew ? customers[0] && customers[0].id : productPackageEntity.customer?.id}
                  required
                >
                  {customers
                    ? customers.map(otherEntity => (
                        <option value={otherEntity.id} key={otherEntity.id}>
                          {otherEntity.email}
                        </option>
                      ))
                    : null}
                </AvInput>
                <AvFeedback>
                  <Translate contentKey="entity.validation.required">This field is required.</Translate>
                </AvFeedback>
              </AvGroup>
              <Button tag={Link} id="cancel-save" to="/product-package" replace color="info">
                <FontAwesomeIcon icon="arrow-left" />
                &nbsp;
                <span className="d-none d-md-inline">
                  <Translate contentKey="entity.action.back">Back</Translate>
                </span>
              </Button>
              &nbsp;
              <Button color="primary" id="save-entity" type="submit" disabled={updating}>
                <FontAwesomeIcon icon="save" />
                &nbsp;
                <Translate contentKey="entity.action.save">Save</Translate>
              </Button>
            </AvForm>
          )}
        </Col>
      </Row>
    </div>
  );
};

const mapStateToProps = (storeState: IRootState) => ({
  customers: storeState.customer.entities,
  productPackageEntity: storeState.productPackage.entity,
  loading: storeState.productPackage.loading,
  updating: storeState.productPackage.updating,
  updateSuccess: storeState.productPackage.updateSuccess,
});

const mapDispatchToProps = {
  getCustomers,
  getEntity,
  updateEntity,
  createEntity,
  reset,
};

type StateProps = ReturnType<typeof mapStateToProps>;
type DispatchProps = typeof mapDispatchToProps;

export default connect(mapStateToProps, mapDispatchToProps)(ProductPackageUpdate);
