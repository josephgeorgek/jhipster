import React, { useState, useEffect } from 'react';
import { connect } from 'react-redux';
import { Link, RouteComponentProps } from 'react-router-dom';
import { Button, Row, Col, Label } from 'reactstrap';
import { AvFeedback, AvForm, AvGroup, AvInput, AvField } from 'availity-reactstrap-validation';
import { Translate, translate, ICrudGetAction, ICrudGetAllAction, ICrudPutAction } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { IRootState } from 'app/shared/reducers';

import { IProduct } from 'app/shared/model/product.model';
import { getEntities as getProducts } from 'app/entities/product/product.reducer';
import { IProductPackage } from 'app/shared/model/product-package.model';
import { getEntities as getProductPackages } from 'app/entities/product-package/product-package.reducer';
import { getEntity, updateEntity, createEntity, reset } from './loan-product.reducer';
import { ILoanProduct } from 'app/shared/model/loan-product.model';
import { convertDateTimeFromServer, convertDateTimeToServer, displayDefaultDateTime } from 'app/shared/util/date-utils';
import { mapIdList } from 'app/shared/util/entity-utils';

export interface ILoanProductUpdateProps extends StateProps, DispatchProps, RouteComponentProps<{ id: string }> {}

export const LoanProductUpdate = (props: ILoanProductUpdateProps) => {
  const [productId, setProductId] = useState('0');
  const [orderId, setOrderId] = useState('0');
  const [isNew, setIsNew] = useState(!props.match.params || !props.match.params.id);

  const { loanProductEntity, products, productPackages, loading, updating } = props;

  const handleClose = () => {
    props.history.push('/loan-product' + props.location.search);
  };

  useEffect(() => {
    if (isNew) {
      props.reset();
    } else {
      props.getEntity(props.match.params.id);
    }

    props.getProducts();
    props.getProductPackages();
  }, []);

  useEffect(() => {
    if (props.updateSuccess) {
      handleClose();
    }
  }, [props.updateSuccess]);

  const saveEntity = (event, errors, values) => {
    if (errors.length === 0) {
      const entity = {
        ...loanProductEntity,
        ...values,
      };

      if (isNew) {
        props.createEntity(entity);
      } else {
        props.updateEntity(entity);
      }
    }
  };

  return (
    <div>
      <Row className="justify-content-center">
        <Col md="8">
          <h2 id="loansApp.loanProduct.home.createOrEditLabel">
            <Translate contentKey="loansApp.loanProduct.home.createOrEditLabel">Create or edit a LoanProduct</Translate>
          </h2>
        </Col>
      </Row>
      <Row className="justify-content-center">
        <Col md="8">
          {loading ? (
            <p>Loading...</p>
          ) : (
            <AvForm model={isNew ? {} : loanProductEntity} onSubmit={saveEntity}>
              {!isNew ? (
                <AvGroup>
                  <Label for="loan-product-id">
                    <Translate contentKey="global.field.id">ID</Translate>
                  </Label>
                  <AvInput id="loan-product-id" type="text" className="form-control" name="id" required readOnly />
                </AvGroup>
              ) : null}
              <AvGroup>
                <Label id="quantityLabel" for="loan-product-quantity">
                  <Translate contentKey="loansApp.loanProduct.quantity">Quantity</Translate>
                </Label>
                <AvField
                  id="loan-product-quantity"
                  type="string"
                  className="form-control"
                  name="quantity"
                  validate={{
                    required: { value: true, errorMessage: translate('entity.validation.required') },
                    min: { value: 0, errorMessage: translate('entity.validation.min', { min: 0 }) },
                    number: { value: true, errorMessage: translate('entity.validation.number') },
                  }}
                />
              </AvGroup>
              <AvGroup>
                <Label id="totalPriceLabel" for="loan-product-totalPrice">
                  <Translate contentKey="loansApp.loanProduct.totalPrice">Total Price</Translate>
                </Label>
                <AvField
                  id="loan-product-totalPrice"
                  type="text"
                  name="totalPrice"
                  validate={{
                    required: { value: true, errorMessage: translate('entity.validation.required') },
                    min: { value: 0, errorMessage: translate('entity.validation.min', { min: 0 }) },
                    number: { value: true, errorMessage: translate('entity.validation.number') },
                  }}
                />
              </AvGroup>
              <AvGroup>
                <Label id="statusLabel" for="loan-product-status">
                  <Translate contentKey="loansApp.loanProduct.status">Status</Translate>
                </Label>
                <AvInput
                  id="loan-product-status"
                  type="select"
                  className="form-control"
                  name="status"
                  value={(!isNew && loanProductEntity.status) || 'AVAILABLE'}
                >
                  <option value="AVAILABLE">{translate('loansApp.LoanProductStatus.AVAILABLE')}</option>
                  <option value="EXIT_FROM_MARKET">{translate('loansApp.LoanProductStatus.EXIT_FROM_MARKET')}</option>
                  <option value="ON_PROMOTION_ONLY">{translate('loansApp.LoanProductStatus.ON_PROMOTION_ONLY')}</option>
                </AvInput>
              </AvGroup>
              <AvGroup>
                <Label for="loan-product-product">
                  <Translate contentKey="loansApp.loanProduct.product">Product</Translate>
                </Label>
                <AvInput
                  id="loan-product-product"
                  type="select"
                  className="form-control"
                  name="product.id"
                  value={isNew ? products[0] && products[0].id : loanProductEntity.product?.id}
                  required
                >
                  {products
                    ? products.map(otherEntity => (
                        <option value={otherEntity.id} key={otherEntity.id}>
                          {otherEntity.name}
                        </option>
                      ))
                    : null}
                </AvInput>
                <AvFeedback>
                  <Translate contentKey="entity.validation.required">This field is required.</Translate>
                </AvFeedback>
              </AvGroup>
              <AvGroup>
                <Label for="loan-product-order">
                  <Translate contentKey="loansApp.loanProduct.order">Order</Translate>
                </Label>
                <AvInput
                  id="loan-product-order"
                  type="select"
                  className="form-control"
                  name="order.id"
                  value={isNew ? productPackages[0] && productPackages[0].id : loanProductEntity.order?.id}
                  required
                >
                  {productPackages
                    ? productPackages.map(otherEntity => (
                        <option value={otherEntity.id} key={otherEntity.id}>
                          {otherEntity.code}
                        </option>
                      ))
                    : null}
                </AvInput>
                <AvFeedback>
                  <Translate contentKey="entity.validation.required">This field is required.</Translate>
                </AvFeedback>
              </AvGroup>
              <Button tag={Link} id="cancel-save" to="/loan-product" replace color="info">
                <FontAwesomeIcon icon="arrow-left" />
                &nbsp;
                <span className="d-none d-md-inline">
                  <Translate contentKey="entity.action.back">Back</Translate>
                </span>
              </Button>
              &nbsp;
              <Button color="primary" id="save-entity" type="submit" disabled={updating}>
                <FontAwesomeIcon icon="save" />
                &nbsp;
                <Translate contentKey="entity.action.save">Save</Translate>
              </Button>
            </AvForm>
          )}
        </Col>
      </Row>
    </div>
  );
};

const mapStateToProps = (storeState: IRootState) => ({
  products: storeState.product.entities,
  productPackages: storeState.productPackage.entities,
  loanProductEntity: storeState.loanProduct.entity,
  loading: storeState.loanProduct.loading,
  updating: storeState.loanProduct.updating,
  updateSuccess: storeState.loanProduct.updateSuccess,
});

const mapDispatchToProps = {
  getProducts,
  getProductPackages,
  getEntity,
  updateEntity,
  createEntity,
  reset,
};

type StateProps = ReturnType<typeof mapStateToProps>;
type DispatchProps = typeof mapDispatchToProps;

export default connect(mapStateToProps, mapDispatchToProps)(LoanProductUpdate);
