import React from 'react';
import { Switch } from 'react-router-dom';

import ErrorBoundaryRoute from 'app/shared/error/error-boundary-route';

import LoanProduct from './loan-product';
import LoanProductDetail from './loan-product-detail';
import LoanProductUpdate from './loan-product-update';
import LoanProductDeleteDialog from './loan-product-delete-dialog';

const Routes = ({ match }) => (
  <>
    <Switch>
      <ErrorBoundaryRoute exact path={`${match.url}/new`} component={LoanProductUpdate} />
      <ErrorBoundaryRoute exact path={`${match.url}/:id/edit`} component={LoanProductUpdate} />
      <ErrorBoundaryRoute exact path={`${match.url}/:id`} component={LoanProductDetail} />
      <ErrorBoundaryRoute path={match.url} component={LoanProduct} />
    </Switch>
    <ErrorBoundaryRoute exact path={`${match.url}/:id/delete`} component={LoanProductDeleteDialog} />
  </>
);

export default Routes;
