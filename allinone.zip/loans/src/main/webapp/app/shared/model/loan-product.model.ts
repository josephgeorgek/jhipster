import { IProduct } from 'app/shared/model/product.model';
import { IProductPackage } from 'app/shared/model/product-package.model';
import { LoanProductStatus } from 'app/shared/model/enumerations/loan-product-status.model';

export interface ILoanProduct {
  id?: number;
  quantity?: number;
  totalPrice?: number;
  status?: LoanProductStatus;
  product?: IProduct;
  order?: IProductPackage;
}

export const defaultValue: Readonly<ILoanProduct> = {};
