import { Moment } from 'moment';
import { ILoanProduct } from 'app/shared/model/loan-product.model';
import { ICustomer } from 'app/shared/model/customer.model';
import { ApplicationStatus } from 'app/shared/model/enumerations/application-status.model';

export interface IProductPackage {
  id?: number;
  placedDate?: string;
  status?: ApplicationStatus;
  code?: string;
  facilityId?: number;
  orderItems?: ILoanProduct[];
  customer?: ICustomer;
}

export const defaultValue: Readonly<IProductPackage> = {};
