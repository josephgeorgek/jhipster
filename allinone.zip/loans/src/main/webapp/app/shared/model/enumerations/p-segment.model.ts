export const enum PSegment {
  PPC = 'PPC',

  SME_S = 'SME_S',

  SME_L = 'SME_L',

  XL = 'XL',

  XXL = 'XXL',
}
