export const enum ApplicationStatus {
  DRAFT = 'DRAFT',

  COMPLETED = 'COMPLETED',

  PENDING = 'PENDING',

  CANCELLED = 'CANCELLED',
}
