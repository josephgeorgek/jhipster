import { Moment } from 'moment';
import { ILoanApplication } from 'app/shared/model/loanApplication/loan-application.model';

export interface IDisbursement {
  id?: number;
  trackingCode?: string;
  date?: string;
  details?: string;
  invoice?: ILoanApplication;
}

export const defaultValue: Readonly<IDisbursement> = {};
