import { IProductCategory } from 'app/shared/model/product-category.model';
import { PSegment } from 'app/shared/model/enumerations/p-segment.model';

export interface IProduct {
  id?: number;
  name?: string;
  description?: string;
  interestRate?: number;
  productSegment?: PSegment;
  imageContentType?: string;
  image?: any;
  productCategory?: IProductCategory;
}

export const defaultValue: Readonly<IProduct> = {};
