import React from 'react';
import { Switch } from 'react-router-dom';

// eslint-disable-next-line @typescript-eslint/no-unused-vars
import ErrorBoundaryRoute from 'app/shared/error/error-boundary-route';

import Product from './product';
import ProductCategory from './product-category';
import Customer from './customer';
import ProductPackage from './product-package';
import LoanProduct from './loan-product';
import LoanApplication from './loanApplication/loan-application';
import Disbursement from './loanApplication/disbursement';
/* jhipster-needle-add-route-import - JHipster will add routes here */

const Routes = ({ match }) => (
  <div>
    <Switch>
      {/* prettier-ignore */}
      <ErrorBoundaryRoute path={`${match.url}product`} component={Product} />
      <ErrorBoundaryRoute path={`${match.url}product-category`} component={ProductCategory} />
      <ErrorBoundaryRoute path={`${match.url}customer`} component={Customer} />
      <ErrorBoundaryRoute path={`${match.url}product-package`} component={ProductPackage} />
      <ErrorBoundaryRoute path={`${match.url}loan-product`} component={LoanProduct} />
      <ErrorBoundaryRoute path={`${match.url}loan-application`} component={LoanApplication} />
      <ErrorBoundaryRoute path={`${match.url}disbursement`} component={Disbursement} />
      {/* jhipster-needle-add-route-path - JHipster will add routes here */}
    </Switch>
  </div>
);

export default Routes;
