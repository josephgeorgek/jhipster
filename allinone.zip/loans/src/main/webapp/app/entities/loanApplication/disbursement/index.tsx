import React from 'react';
import { Switch } from 'react-router-dom';

import ErrorBoundaryRoute from 'app/shared/error/error-boundary-route';

import Disbursement from './disbursement';
import DisbursementDetail from './disbursement-detail';
import DisbursementUpdate from './disbursement-update';
import DisbursementDeleteDialog from './disbursement-delete-dialog';

const Routes = ({ match }) => (
  <>
    <Switch>
      <ErrorBoundaryRoute exact path={`${match.url}/new`} component={DisbursementUpdate} />
      <ErrorBoundaryRoute exact path={`${match.url}/:id/edit`} component={DisbursementUpdate} />
      <ErrorBoundaryRoute exact path={`${match.url}/:id`} component={DisbursementDetail} />
      <ErrorBoundaryRoute path={match.url} component={Disbursement} />
    </Switch>
    <ErrorBoundaryRoute exact path={`${match.url}/:id/delete`} component={DisbursementDeleteDialog} />
  </>
);

export default Routes;
