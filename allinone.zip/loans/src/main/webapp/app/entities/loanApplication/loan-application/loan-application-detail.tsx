import React, { useEffect } from 'react';
import { connect } from 'react-redux';
import { Link, RouteComponentProps } from 'react-router-dom';
import { Button, Row, Col } from 'reactstrap';
import { Translate, ICrudGetAction, TextFormat } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { IRootState } from 'app/shared/reducers';
import { getEntity } from './loan-application.reducer';
import { ILoanApplication } from 'app/shared/model/loanApplication/loan-application.model';
import { APP_DATE_FORMAT, APP_LOCAL_DATE_FORMAT } from 'app/config/constants';

export interface ILoanApplicationDetailProps extends StateProps, DispatchProps, RouteComponentProps<{ id: string }> {}

export const LoanApplicationDetail = (props: ILoanApplicationDetailProps) => {
  useEffect(() => {
    props.getEntity(props.match.params.id);
  }, []);

  const { loanApplicationEntity } = props;
  return (
    <Row>
      <Col md="8">
        <h2>
          <Translate contentKey="loansApp.loanApplicationLoanApplication.detail.title">LoanApplication</Translate> [
          <b>{loanApplicationEntity.id}</b>]
        </h2>
        <dl className="jh-entity-details">
          <dt>
            <span id="code">
              <Translate contentKey="loansApp.loanApplicationLoanApplication.code">Code</Translate>
            </span>
          </dt>
          <dd>{loanApplicationEntity.code}</dd>
          <dt>
            <span id="date">
              <Translate contentKey="loansApp.loanApplicationLoanApplication.date">Date</Translate>
            </span>
          </dt>
          <dd>
            {loanApplicationEntity.date ? <TextFormat value={loanApplicationEntity.date} type="date" format={APP_DATE_FORMAT} /> : null}
          </dd>
          <dt>
            <span id="details">
              <Translate contentKey="loansApp.loanApplicationLoanApplication.details">Details</Translate>
            </span>
          </dt>
          <dd>{loanApplicationEntity.details}</dd>
          <dt>
            <span id="status">
              <Translate contentKey="loansApp.loanApplicationLoanApplication.status">Status</Translate>
            </span>
          </dt>
          <dd>{loanApplicationEntity.status}</dd>
          <dt>
            <span id="paymentMethod">
              <Translate contentKey="loansApp.loanApplicationLoanApplication.paymentMethod">Payment Method</Translate>
            </span>
          </dt>
          <dd>{loanApplicationEntity.paymentMethod}</dd>
          <dt>
            <span id="disburementDate">
              <Translate contentKey="loansApp.loanApplicationLoanApplication.disburementDate">Disburement Date</Translate>
            </span>
          </dt>
          <dd>
            {loanApplicationEntity.disburementDate ? (
              <TextFormat value={loanApplicationEntity.disburementDate} type="date" format={APP_DATE_FORMAT} />
            ) : null}
          </dd>
          <dt>
            <span id="amount">
              <Translate contentKey="loansApp.loanApplicationLoanApplication.amount">Amount</Translate>
            </span>
          </dt>
          <dd>{loanApplicationEntity.amount}</dd>
        </dl>
        <Button tag={Link} to="/loan-application" replace color="info">
          <FontAwesomeIcon icon="arrow-left" />{' '}
          <span className="d-none d-md-inline">
            <Translate contentKey="entity.action.back">Back</Translate>
          </span>
        </Button>
        &nbsp;
        <Button tag={Link} to={`/loan-application/${loanApplicationEntity.id}/edit`} replace color="primary">
          <FontAwesomeIcon icon="pencil-alt" />{' '}
          <span className="d-none d-md-inline">
            <Translate contentKey="entity.action.edit">Edit</Translate>
          </span>
        </Button>
      </Col>
    </Row>
  );
};

const mapStateToProps = ({ loanApplication }: IRootState) => ({
  loanApplicationEntity: loanApplication.entity,
});

const mapDispatchToProps = { getEntity };

type StateProps = ReturnType<typeof mapStateToProps>;
type DispatchProps = typeof mapDispatchToProps;

export default connect(mapStateToProps, mapDispatchToProps)(LoanApplicationDetail);
