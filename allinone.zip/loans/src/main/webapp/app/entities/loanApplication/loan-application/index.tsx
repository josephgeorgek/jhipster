import React from 'react';
import { Switch } from 'react-router-dom';

import ErrorBoundaryRoute from 'app/shared/error/error-boundary-route';

import LoanApplication from './loan-application';
import LoanApplicationDetail from './loan-application-detail';
import LoanApplicationUpdate from './loan-application-update';
import LoanApplicationDeleteDialog from './loan-application-delete-dialog';

const Routes = ({ match }) => (
  <>
    <Switch>
      <ErrorBoundaryRoute exact path={`${match.url}/new`} component={LoanApplicationUpdate} />
      <ErrorBoundaryRoute exact path={`${match.url}/:id/edit`} component={LoanApplicationUpdate} />
      <ErrorBoundaryRoute exact path={`${match.url}/:id`} component={LoanApplicationDetail} />
      <ErrorBoundaryRoute path={match.url} component={LoanApplication} />
    </Switch>
    <ErrorBoundaryRoute exact path={`${match.url}/:id/delete`} component={LoanApplicationDeleteDialog} />
  </>
);

export default Routes;
