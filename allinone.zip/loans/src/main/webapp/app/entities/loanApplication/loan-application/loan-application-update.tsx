import React, { useState, useEffect } from 'react';
import { connect } from 'react-redux';
import { Link, RouteComponentProps } from 'react-router-dom';
import { Button, Row, Col, Label } from 'reactstrap';
import { AvFeedback, AvForm, AvGroup, AvInput, AvField } from 'availity-reactstrap-validation';
import { Translate, translate, ICrudGetAction, ICrudGetAllAction, ICrudPutAction } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { IRootState } from 'app/shared/reducers';

import { getEntity, updateEntity, createEntity, reset } from './loan-application.reducer';
import { ILoanApplication } from 'app/shared/model/loanApplication/loan-application.model';
import { convertDateTimeFromServer, convertDateTimeToServer, displayDefaultDateTime } from 'app/shared/util/date-utils';
import { mapIdList } from 'app/shared/util/entity-utils';

export interface ILoanApplicationUpdateProps extends StateProps, DispatchProps, RouteComponentProps<{ id: string }> {}

export const LoanApplicationUpdate = (props: ILoanApplicationUpdateProps) => {
  const [isNew, setIsNew] = useState(!props.match.params || !props.match.params.id);

  const { loanApplicationEntity, loading, updating } = props;

  const handleClose = () => {
    props.history.push('/loan-application' + props.location.search);
  };

  useEffect(() => {
    if (isNew) {
      props.reset();
    } else {
      props.getEntity(props.match.params.id);
    }
  }, []);

  useEffect(() => {
    if (props.updateSuccess) {
      handleClose();
    }
  }, [props.updateSuccess]);

  const saveEntity = (event, errors, values) => {
    values.date = convertDateTimeToServer(values.date);
    values.disburementDate = convertDateTimeToServer(values.disburementDate);

    if (errors.length === 0) {
      const entity = {
        ...loanApplicationEntity,
        ...values,
      };

      if (isNew) {
        props.createEntity(entity);
      } else {
        props.updateEntity(entity);
      }
    }
  };

  return (
    <div>
      <Row className="justify-content-center">
        <Col md="8">
          <h2 id="loansApp.loanApplicationLoanApplication.home.createOrEditLabel">
            <Translate contentKey="loansApp.loanApplicationLoanApplication.home.createOrEditLabel">
              Create or edit a LoanApplication
            </Translate>
          </h2>
        </Col>
      </Row>
      <Row className="justify-content-center">
        <Col md="8">
          {loading ? (
            <p>Loading...</p>
          ) : (
            <AvForm model={isNew ? {} : loanApplicationEntity} onSubmit={saveEntity}>
              {!isNew ? (
                <AvGroup>
                  <Label for="loan-application-id">
                    <Translate contentKey="global.field.id">ID</Translate>
                  </Label>
                  <AvInput id="loan-application-id" type="text" className="form-control" name="id" required readOnly />
                </AvGroup>
              ) : null}
              <AvGroup>
                <Label id="codeLabel" for="loan-application-code">
                  <Translate contentKey="loansApp.loanApplicationLoanApplication.code">Code</Translate>
                </Label>
                <AvField
                  id="loan-application-code"
                  type="text"
                  name="code"
                  validate={{
                    required: { value: true, errorMessage: translate('entity.validation.required') },
                  }}
                />
              </AvGroup>
              <AvGroup>
                <Label id="dateLabel" for="loan-application-date">
                  <Translate contentKey="loansApp.loanApplicationLoanApplication.date">Date</Translate>
                </Label>
                <AvInput
                  id="loan-application-date"
                  type="datetime-local"
                  className="form-control"
                  name="date"
                  placeholder={'YYYY-MM-DD HH:mm'}
                  value={isNew ? displayDefaultDateTime() : convertDateTimeFromServer(props.loanApplicationEntity.date)}
                  validate={{
                    required: { value: true, errorMessage: translate('entity.validation.required') },
                  }}
                />
              </AvGroup>
              <AvGroup>
                <Label id="detailsLabel" for="loan-application-details">
                  <Translate contentKey="loansApp.loanApplicationLoanApplication.details">Details</Translate>
                </Label>
                <AvField id="loan-application-details" type="text" name="details" />
              </AvGroup>
              <AvGroup>
                <Label id="statusLabel" for="loan-application-status">
                  <Translate contentKey="loansApp.loanApplicationLoanApplication.status">Status</Translate>
                </Label>
                <AvInput
                  id="loan-application-status"
                  type="select"
                  className="form-control"
                  name="status"
                  value={(!isNew && loanApplicationEntity.status) || 'APPROVED'}
                >
                  <option value="APPROVED">{translate('loansApp.LoanApplicationStatus.APPROVED')}</option>
                  <option value="PAID">{translate('loansApp.LoanApplicationStatus.PAID')}</option>
                  <option value="ISSUED">{translate('loansApp.LoanApplicationStatus.ISSUED')}</option>
                  <option value="CANCELLED">{translate('loansApp.LoanApplicationStatus.CANCELLED')}</option>
                </AvInput>
              </AvGroup>
              <AvGroup>
                <Label id="paymentMethodLabel" for="loan-application-paymentMethod">
                  <Translate contentKey="loansApp.loanApplicationLoanApplication.paymentMethod">Payment Method</Translate>
                </Label>
                <AvInput
                  id="loan-application-paymentMethod"
                  type="select"
                  className="form-control"
                  name="paymentMethod"
                  value={(!isNew && loanApplicationEntity.paymentMethod) || 'OD'}
                >
                  <option value="OD">{translate('loansApp.DisbursementMethod.OD')}</option>
                  <option value="ACCOUNT">{translate('loansApp.DisbursementMethod.ACCOUNT')}</option>
                  <option value="GIRO">{translate('loansApp.DisbursementMethod.GIRO')}</option>
                </AvInput>
              </AvGroup>
              <AvGroup>
                <Label id="disburementDateLabel" for="loan-application-disburementDate">
                  <Translate contentKey="loansApp.loanApplicationLoanApplication.disburementDate">Disburement Date</Translate>
                </Label>
                <AvInput
                  id="loan-application-disburementDate"
                  type="datetime-local"
                  className="form-control"
                  name="disburementDate"
                  placeholder={'YYYY-MM-DD HH:mm'}
                  value={isNew ? displayDefaultDateTime() : convertDateTimeFromServer(props.loanApplicationEntity.disburementDate)}
                  validate={{
                    required: { value: true, errorMessage: translate('entity.validation.required') },
                  }}
                />
              </AvGroup>
              <AvGroup>
                <Label id="amountLabel" for="loan-application-amount">
                  <Translate contentKey="loansApp.loanApplicationLoanApplication.amount">Amount</Translate>
                </Label>
                <AvField
                  id="loan-application-amount"
                  type="text"
                  name="amount"
                  validate={{
                    required: { value: true, errorMessage: translate('entity.validation.required') },
                    number: { value: true, errorMessage: translate('entity.validation.number') },
                  }}
                />
              </AvGroup>
              <Button tag={Link} id="cancel-save" to="/loan-application" replace color="info">
                <FontAwesomeIcon icon="arrow-left" />
                &nbsp;
                <span className="d-none d-md-inline">
                  <Translate contentKey="entity.action.back">Back</Translate>
                </span>
              </Button>
              &nbsp;
              <Button color="primary" id="save-entity" type="submit" disabled={updating}>
                <FontAwesomeIcon icon="save" />
                &nbsp;
                <Translate contentKey="entity.action.save">Save</Translate>
              </Button>
            </AvForm>
          )}
        </Col>
      </Row>
    </div>
  );
};

const mapStateToProps = (storeState: IRootState) => ({
  loanApplicationEntity: storeState.loanApplication.entity,
  loading: storeState.loanApplication.loading,
  updating: storeState.loanApplication.updating,
  updateSuccess: storeState.loanApplication.updateSuccess,
});

const mapDispatchToProps = {
  getEntity,
  updateEntity,
  createEntity,
  reset,
};

type StateProps = ReturnType<typeof mapStateToProps>;
type DispatchProps = typeof mapDispatchToProps;

export default connect(mapStateToProps, mapDispatchToProps)(LoanApplicationUpdate);
