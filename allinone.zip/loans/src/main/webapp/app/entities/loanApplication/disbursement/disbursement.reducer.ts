import axios from 'axios';
import { ICrudGetAction, ICrudGetAllAction, ICrudPutAction, ICrudDeleteAction } from 'react-jhipster';

import { cleanEntity } from 'app/shared/util/entity-utils';
import { REQUEST, SUCCESS, FAILURE } from 'app/shared/reducers/action-type.util';

import { IDisbursement, defaultValue } from 'app/shared/model/loanApplication/disbursement.model';

export const ACTION_TYPES = {
  FETCH_DISBURSEMENT_LIST: 'disbursement/FETCH_DISBURSEMENT_LIST',
  FETCH_DISBURSEMENT: 'disbursement/FETCH_DISBURSEMENT',
  CREATE_DISBURSEMENT: 'disbursement/CREATE_DISBURSEMENT',
  UPDATE_DISBURSEMENT: 'disbursement/UPDATE_DISBURSEMENT',
  DELETE_DISBURSEMENT: 'disbursement/DELETE_DISBURSEMENT',
  RESET: 'disbursement/RESET',
};

const initialState = {
  loading: false,
  errorMessage: null,
  entities: [] as ReadonlyArray<IDisbursement>,
  entity: defaultValue,
  updating: false,
  totalItems: 0,
  updateSuccess: false,
};

export type DisbursementState = Readonly<typeof initialState>;

// Reducer

export default (state: DisbursementState = initialState, action): DisbursementState => {
  switch (action.type) {
    case REQUEST(ACTION_TYPES.FETCH_DISBURSEMENT_LIST):
    case REQUEST(ACTION_TYPES.FETCH_DISBURSEMENT):
      return {
        ...state,
        errorMessage: null,
        updateSuccess: false,
        loading: true,
      };
    case REQUEST(ACTION_TYPES.CREATE_DISBURSEMENT):
    case REQUEST(ACTION_TYPES.UPDATE_DISBURSEMENT):
    case REQUEST(ACTION_TYPES.DELETE_DISBURSEMENT):
      return {
        ...state,
        errorMessage: null,
        updateSuccess: false,
        updating: true,
      };
    case FAILURE(ACTION_TYPES.FETCH_DISBURSEMENT_LIST):
    case FAILURE(ACTION_TYPES.FETCH_DISBURSEMENT):
    case FAILURE(ACTION_TYPES.CREATE_DISBURSEMENT):
    case FAILURE(ACTION_TYPES.UPDATE_DISBURSEMENT):
    case FAILURE(ACTION_TYPES.DELETE_DISBURSEMENT):
      return {
        ...state,
        loading: false,
        updating: false,
        updateSuccess: false,
        errorMessage: action.payload,
      };
    case SUCCESS(ACTION_TYPES.FETCH_DISBURSEMENT_LIST):
      return {
        ...state,
        loading: false,
        entities: action.payload.data,
        totalItems: parseInt(action.payload.headers['x-total-count'], 10),
      };
    case SUCCESS(ACTION_TYPES.FETCH_DISBURSEMENT):
      return {
        ...state,
        loading: false,
        entity: action.payload.data,
      };
    case SUCCESS(ACTION_TYPES.CREATE_DISBURSEMENT):
    case SUCCESS(ACTION_TYPES.UPDATE_DISBURSEMENT):
      return {
        ...state,
        updating: false,
        updateSuccess: true,
        entity: action.payload.data,
      };
    case SUCCESS(ACTION_TYPES.DELETE_DISBURSEMENT):
      return {
        ...state,
        updating: false,
        updateSuccess: true,
        entity: {},
      };
    case ACTION_TYPES.RESET:
      return {
        ...initialState,
      };
    default:
      return state;
  }
};

const apiUrl = 'services/loanapplication/api/disbursements';

// Actions

export const getEntities: ICrudGetAllAction<IDisbursement> = (page, size, sort) => {
  const requestUrl = `${apiUrl}${sort ? `?page=${page}&size=${size}&sort=${sort}` : ''}`;
  return {
    type: ACTION_TYPES.FETCH_DISBURSEMENT_LIST,
    payload: axios.get<IDisbursement>(`${requestUrl}${sort ? '&' : '?'}cacheBuster=${new Date().getTime()}`),
  };
};

export const getEntity: ICrudGetAction<IDisbursement> = id => {
  const requestUrl = `${apiUrl}/${id}`;
  return {
    type: ACTION_TYPES.FETCH_DISBURSEMENT,
    payload: axios.get<IDisbursement>(requestUrl),
  };
};

export const createEntity: ICrudPutAction<IDisbursement> = entity => async dispatch => {
  const result = await dispatch({
    type: ACTION_TYPES.CREATE_DISBURSEMENT,
    payload: axios.post(apiUrl, cleanEntity(entity)),
  });
  dispatch(getEntities());
  return result;
};

export const updateEntity: ICrudPutAction<IDisbursement> = entity => async dispatch => {
  const result = await dispatch({
    type: ACTION_TYPES.UPDATE_DISBURSEMENT,
    payload: axios.put(apiUrl, cleanEntity(entity)),
  });
  return result;
};

export const deleteEntity: ICrudDeleteAction<IDisbursement> = id => async dispatch => {
  const requestUrl = `${apiUrl}/${id}`;
  const result = await dispatch({
    type: ACTION_TYPES.DELETE_DISBURSEMENT,
    payload: axios.delete(requestUrl),
  });
  dispatch(getEntities());
  return result;
};

export const reset = () => ({
  type: ACTION_TYPES.RESET,
});
