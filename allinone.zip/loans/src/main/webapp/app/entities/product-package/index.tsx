import React from 'react';
import { Switch } from 'react-router-dom';

import ErrorBoundaryRoute from 'app/shared/error/error-boundary-route';

import ProductPackage from './product-package';
import ProductPackageDetail from './product-package-detail';
import ProductPackageUpdate from './product-package-update';
import ProductPackageDeleteDialog from './product-package-delete-dialog';

const Routes = ({ match }) => (
  <>
    <Switch>
      <ErrorBoundaryRoute exact path={`${match.url}/new`} component={ProductPackageUpdate} />
      <ErrorBoundaryRoute exact path={`${match.url}/:id/edit`} component={ProductPackageUpdate} />
      <ErrorBoundaryRoute exact path={`${match.url}/:id`} component={ProductPackageDetail} />
      <ErrorBoundaryRoute path={match.url} component={ProductPackage} />
    </Switch>
    <ErrorBoundaryRoute exact path={`${match.url}/:id/delete`} component={ProductPackageDeleteDialog} />
  </>
);

export default Routes;
