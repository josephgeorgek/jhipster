import axios from 'axios';
import { ICrudGetAction, ICrudGetAllAction, ICrudPutAction, ICrudDeleteAction } from 'react-jhipster';

import { cleanEntity } from 'app/shared/util/entity-utils';
import { REQUEST, SUCCESS, FAILURE } from 'app/shared/reducers/action-type.util';

import { ILoanProduct, defaultValue } from 'app/shared/model/loan-product.model';

export const ACTION_TYPES = {
  FETCH_LOANPRODUCT_LIST: 'loanProduct/FETCH_LOANPRODUCT_LIST',
  FETCH_LOANPRODUCT: 'loanProduct/FETCH_LOANPRODUCT',
  CREATE_LOANPRODUCT: 'loanProduct/CREATE_LOANPRODUCT',
  UPDATE_LOANPRODUCT: 'loanProduct/UPDATE_LOANPRODUCT',
  DELETE_LOANPRODUCT: 'loanProduct/DELETE_LOANPRODUCT',
  RESET: 'loanProduct/RESET',
};

const initialState = {
  loading: false,
  errorMessage: null,
  entities: [] as ReadonlyArray<ILoanProduct>,
  entity: defaultValue,
  updating: false,
  totalItems: 0,
  updateSuccess: false,
};

export type LoanProductState = Readonly<typeof initialState>;

// Reducer

export default (state: LoanProductState = initialState, action): LoanProductState => {
  switch (action.type) {
    case REQUEST(ACTION_TYPES.FETCH_LOANPRODUCT_LIST):
    case REQUEST(ACTION_TYPES.FETCH_LOANPRODUCT):
      return {
        ...state,
        errorMessage: null,
        updateSuccess: false,
        loading: true,
      };
    case REQUEST(ACTION_TYPES.CREATE_LOANPRODUCT):
    case REQUEST(ACTION_TYPES.UPDATE_LOANPRODUCT):
    case REQUEST(ACTION_TYPES.DELETE_LOANPRODUCT):
      return {
        ...state,
        errorMessage: null,
        updateSuccess: false,
        updating: true,
      };
    case FAILURE(ACTION_TYPES.FETCH_LOANPRODUCT_LIST):
    case FAILURE(ACTION_TYPES.FETCH_LOANPRODUCT):
    case FAILURE(ACTION_TYPES.CREATE_LOANPRODUCT):
    case FAILURE(ACTION_TYPES.UPDATE_LOANPRODUCT):
    case FAILURE(ACTION_TYPES.DELETE_LOANPRODUCT):
      return {
        ...state,
        loading: false,
        updating: false,
        updateSuccess: false,
        errorMessage: action.payload,
      };
    case SUCCESS(ACTION_TYPES.FETCH_LOANPRODUCT_LIST):
      return {
        ...state,
        loading: false,
        entities: action.payload.data,
        totalItems: parseInt(action.payload.headers['x-total-count'], 10),
      };
    case SUCCESS(ACTION_TYPES.FETCH_LOANPRODUCT):
      return {
        ...state,
        loading: false,
        entity: action.payload.data,
      };
    case SUCCESS(ACTION_TYPES.CREATE_LOANPRODUCT):
    case SUCCESS(ACTION_TYPES.UPDATE_LOANPRODUCT):
      return {
        ...state,
        updating: false,
        updateSuccess: true,
        entity: action.payload.data,
      };
    case SUCCESS(ACTION_TYPES.DELETE_LOANPRODUCT):
      return {
        ...state,
        updating: false,
        updateSuccess: true,
        entity: {},
      };
    case ACTION_TYPES.RESET:
      return {
        ...initialState,
      };
    default:
      return state;
  }
};

const apiUrl = 'api/loan-products';

// Actions

export const getEntities: ICrudGetAllAction<ILoanProduct> = (page, size, sort) => {
  const requestUrl = `${apiUrl}${sort ? `?page=${page}&size=${size}&sort=${sort}` : ''}`;
  return {
    type: ACTION_TYPES.FETCH_LOANPRODUCT_LIST,
    payload: axios.get<ILoanProduct>(`${requestUrl}${sort ? '&' : '?'}cacheBuster=${new Date().getTime()}`),
  };
};

export const getEntity: ICrudGetAction<ILoanProduct> = id => {
  const requestUrl = `${apiUrl}/${id}`;
  return {
    type: ACTION_TYPES.FETCH_LOANPRODUCT,
    payload: axios.get<ILoanProduct>(requestUrl),
  };
};

export const createEntity: ICrudPutAction<ILoanProduct> = entity => async dispatch => {
  const result = await dispatch({
    type: ACTION_TYPES.CREATE_LOANPRODUCT,
    payload: axios.post(apiUrl, cleanEntity(entity)),
  });
  dispatch(getEntities());
  return result;
};

export const updateEntity: ICrudPutAction<ILoanProduct> = entity => async dispatch => {
  const result = await dispatch({
    type: ACTION_TYPES.UPDATE_LOANPRODUCT,
    payload: axios.put(apiUrl, cleanEntity(entity)),
  });
  return result;
};

export const deleteEntity: ICrudDeleteAction<ILoanProduct> = id => async dispatch => {
  const requestUrl = `${apiUrl}/${id}`;
  const result = await dispatch({
    type: ACTION_TYPES.DELETE_LOANPRODUCT,
    payload: axios.delete(requestUrl),
  });
  dispatch(getEntities());
  return result;
};

export const reset = () => ({
  type: ACTION_TYPES.RESET,
});
