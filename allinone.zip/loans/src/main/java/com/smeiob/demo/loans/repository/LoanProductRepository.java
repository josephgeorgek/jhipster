package com.smeiob.demo.loans.repository;

import com.smeiob.demo.loans.domain.LoanProduct;

import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

/**
 * Spring Data  repository for the LoanProduct entity.
 */
@SuppressWarnings("unused")
@Repository
public interface LoanProductRepository extends JpaRepository<LoanProduct, Long> {
}
