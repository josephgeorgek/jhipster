/**
 * Spring Data JPA repositories.
 */
package com.smeiob.demo.loans.repository;
