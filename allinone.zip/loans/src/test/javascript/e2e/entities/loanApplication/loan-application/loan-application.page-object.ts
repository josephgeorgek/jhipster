import { element, by, ElementFinder, ElementArrayFinder } from 'protractor';

import { waitUntilAnyDisplayed, waitUntilDisplayed, click, waitUntilHidden, isVisible } from '../../../util/utils';

import NavBarPage from './../../../page-objects/navbar-page';

import LoanApplicationUpdatePage from './loan-application-update.page-object';

const expect = chai.expect;
export class LoanApplicationDeleteDialog {
  deleteModal = element(by.className('modal'));
  private dialogTitle: ElementFinder = element(by.id('loansApp.loanApplicationLoanApplication.delete.question'));
  private confirmButton = element(by.id('jhi-confirm-delete-loanApplication'));

  getDialogTitle() {
    return this.dialogTitle;
  }

  async clickOnConfirmButton() {
    await this.confirmButton.click();
  }
}

export default class LoanApplicationComponentsPage {
  createButton: ElementFinder = element(by.id('jh-create-entity'));
  deleteButtons = element.all(by.css('div table .btn-danger'));
  title: ElementFinder = element(by.id('loan-application-heading'));
  noRecords: ElementFinder = element(by.css('#app-view-container .table-responsive div.alert.alert-warning'));
  table: ElementFinder = element(by.css('#app-view-container div.table-responsive > table'));

  records: ElementArrayFinder = this.table.all(by.css('tbody tr'));

  getDetailsButton(record: ElementFinder) {
    return record.element(by.css('a.btn.btn-info.btn-sm'));
  }

  getEditButton(record: ElementFinder) {
    return record.element(by.css('a.btn.btn-primary.btn-sm'));
  }

  getDeleteButton(record: ElementFinder) {
    return record.element(by.css('a.btn.btn-danger.btn-sm'));
  }

  async goToPage(navBarPage: NavBarPage) {
    await navBarPage.getEntityPage('loan-application');
    await waitUntilAnyDisplayed([this.noRecords, this.table]);
    return this;
  }

  async goToCreateLoanApplication() {
    await this.createButton.click();
    return new LoanApplicationUpdatePage();
  }

  async deleteLoanApplication() {
    const deleteButton = this.getDeleteButton(this.records.last());
    await click(deleteButton);

    const loanApplicationDeleteDialog = new LoanApplicationDeleteDialog();
    await waitUntilDisplayed(loanApplicationDeleteDialog.deleteModal);
    expect(await loanApplicationDeleteDialog.getDialogTitle().getAttribute('id')).to.match(
      /loansApp.loanApplicationLoanApplication.delete.question/
    );
    await loanApplicationDeleteDialog.clickOnConfirmButton();

    await waitUntilHidden(loanApplicationDeleteDialog.deleteModal);

    expect(await isVisible(loanApplicationDeleteDialog.deleteModal)).to.be.false;
  }
}
