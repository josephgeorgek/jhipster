package com.smeiob.demo.invoice.web.rest;

import com.smeiob.demo.invoice.LoanApplicationApp;
import com.smeiob.demo.invoice.domain.Disbursement;
import com.smeiob.demo.invoice.domain.LoanApplication;
import com.smeiob.demo.invoice.repository.DisbursementRepository;
import com.smeiob.demo.invoice.service.DisbursementService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;
import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Integration tests for the {@link DisbursementResource} REST controller.
 */
@SpringBootTest(classes = LoanApplicationApp.class)
@AutoConfigureMockMvc
@WithMockUser
public class DisbursementResourceIT {

    private static final String DEFAULT_TRACKING_CODE = "AAAAAAAAAA";
    private static final String UPDATED_TRACKING_CODE = "BBBBBBBBBB";

    private static final Instant DEFAULT_DATE = Instant.ofEpochMilli(0L);
    private static final Instant UPDATED_DATE = Instant.now().truncatedTo(ChronoUnit.MILLIS);

    private static final String DEFAULT_DETAILS = "AAAAAAAAAA";
    private static final String UPDATED_DETAILS = "BBBBBBBBBB";

    @Autowired
    private DisbursementRepository disbursementRepository;

    @Autowired
    private DisbursementService disbursementService;

    @Autowired
    private EntityManager em;

    @Autowired
    private MockMvc restDisbursementMockMvc;

    private Disbursement disbursement;

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Disbursement createEntity(EntityManager em) {
        Disbursement disbursement = new Disbursement()
            .trackingCode(DEFAULT_TRACKING_CODE)
            .date(DEFAULT_DATE)
            .details(DEFAULT_DETAILS);
        // Add required entity
        LoanApplication loanApplication;
        if (TestUtil.findAll(em, LoanApplication.class).isEmpty()) {
            loanApplication = LoanApplicationResourceIT.createEntity(em);
            em.persist(loanApplication);
            em.flush();
        } else {
            loanApplication = TestUtil.findAll(em, LoanApplication.class).get(0);
        }
        disbursement.setInvoice(loanApplication);
        return disbursement;
    }
    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Disbursement createUpdatedEntity(EntityManager em) {
        Disbursement disbursement = new Disbursement()
            .trackingCode(UPDATED_TRACKING_CODE)
            .date(UPDATED_DATE)
            .details(UPDATED_DETAILS);
        // Add required entity
        LoanApplication loanApplication;
        if (TestUtil.findAll(em, LoanApplication.class).isEmpty()) {
            loanApplication = LoanApplicationResourceIT.createUpdatedEntity(em);
            em.persist(loanApplication);
            em.flush();
        } else {
            loanApplication = TestUtil.findAll(em, LoanApplication.class).get(0);
        }
        disbursement.setInvoice(loanApplication);
        return disbursement;
    }

    @BeforeEach
    public void initTest() {
        disbursement = createEntity(em);
    }

    @Test
    @Transactional
    public void createDisbursement() throws Exception {
        int databaseSizeBeforeCreate = disbursementRepository.findAll().size();
        // Create the Disbursement
        restDisbursementMockMvc.perform(post("/api/disbursements")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(disbursement)))
            .andExpect(status().isCreated());

        // Validate the Disbursement in the database
        List<Disbursement> disbursementList = disbursementRepository.findAll();
        assertThat(disbursementList).hasSize(databaseSizeBeforeCreate + 1);
        Disbursement testDisbursement = disbursementList.get(disbursementList.size() - 1);
        assertThat(testDisbursement.getTrackingCode()).isEqualTo(DEFAULT_TRACKING_CODE);
        assertThat(testDisbursement.getDate()).isEqualTo(DEFAULT_DATE);
        assertThat(testDisbursement.getDetails()).isEqualTo(DEFAULT_DETAILS);
    }

    @Test
    @Transactional
    public void createDisbursementWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = disbursementRepository.findAll().size();

        // Create the Disbursement with an existing ID
        disbursement.setId(1L);

        // An entity with an existing ID cannot be created, so this API call must fail
        restDisbursementMockMvc.perform(post("/api/disbursements")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(disbursement)))
            .andExpect(status().isBadRequest());

        // Validate the Disbursement in the database
        List<Disbursement> disbursementList = disbursementRepository.findAll();
        assertThat(disbursementList).hasSize(databaseSizeBeforeCreate);
    }


    @Test
    @Transactional
    public void checkDateIsRequired() throws Exception {
        int databaseSizeBeforeTest = disbursementRepository.findAll().size();
        // set the field null
        disbursement.setDate(null);

        // Create the Disbursement, which fails.


        restDisbursementMockMvc.perform(post("/api/disbursements")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(disbursement)))
            .andExpect(status().isBadRequest());

        List<Disbursement> disbursementList = disbursementRepository.findAll();
        assertThat(disbursementList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllDisbursements() throws Exception {
        // Initialize the database
        disbursementRepository.saveAndFlush(disbursement);

        // Get all the disbursementList
        restDisbursementMockMvc.perform(get("/api/disbursements?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(disbursement.getId().intValue())))
            .andExpect(jsonPath("$.[*].trackingCode").value(hasItem(DEFAULT_TRACKING_CODE)))
            .andExpect(jsonPath("$.[*].date").value(hasItem(DEFAULT_DATE.toString())))
            .andExpect(jsonPath("$.[*].details").value(hasItem(DEFAULT_DETAILS)));
    }
    
    @Test
    @Transactional
    public void getDisbursement() throws Exception {
        // Initialize the database
        disbursementRepository.saveAndFlush(disbursement);

        // Get the disbursement
        restDisbursementMockMvc.perform(get("/api/disbursements/{id}", disbursement.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.id").value(disbursement.getId().intValue()))
            .andExpect(jsonPath("$.trackingCode").value(DEFAULT_TRACKING_CODE))
            .andExpect(jsonPath("$.date").value(DEFAULT_DATE.toString()))
            .andExpect(jsonPath("$.details").value(DEFAULT_DETAILS));
    }
    @Test
    @Transactional
    public void getNonExistingDisbursement() throws Exception {
        // Get the disbursement
        restDisbursementMockMvc.perform(get("/api/disbursements/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateDisbursement() throws Exception {
        // Initialize the database
        disbursementService.save(disbursement);

        int databaseSizeBeforeUpdate = disbursementRepository.findAll().size();

        // Update the disbursement
        Disbursement updatedDisbursement = disbursementRepository.findById(disbursement.getId()).get();
        // Disconnect from session so that the updates on updatedDisbursement are not directly saved in db
        em.detach(updatedDisbursement);
        updatedDisbursement
            .trackingCode(UPDATED_TRACKING_CODE)
            .date(UPDATED_DATE)
            .details(UPDATED_DETAILS);

        restDisbursementMockMvc.perform(put("/api/disbursements")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(updatedDisbursement)))
            .andExpect(status().isOk());

        // Validate the Disbursement in the database
        List<Disbursement> disbursementList = disbursementRepository.findAll();
        assertThat(disbursementList).hasSize(databaseSizeBeforeUpdate);
        Disbursement testDisbursement = disbursementList.get(disbursementList.size() - 1);
        assertThat(testDisbursement.getTrackingCode()).isEqualTo(UPDATED_TRACKING_CODE);
        assertThat(testDisbursement.getDate()).isEqualTo(UPDATED_DATE);
        assertThat(testDisbursement.getDetails()).isEqualTo(UPDATED_DETAILS);
    }

    @Test
    @Transactional
    public void updateNonExistingDisbursement() throws Exception {
        int databaseSizeBeforeUpdate = disbursementRepository.findAll().size();

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restDisbursementMockMvc.perform(put("/api/disbursements")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(disbursement)))
            .andExpect(status().isBadRequest());

        // Validate the Disbursement in the database
        List<Disbursement> disbursementList = disbursementRepository.findAll();
        assertThat(disbursementList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    public void deleteDisbursement() throws Exception {
        // Initialize the database
        disbursementService.save(disbursement);

        int databaseSizeBeforeDelete = disbursementRepository.findAll().size();

        // Delete the disbursement
        restDisbursementMockMvc.perform(delete("/api/disbursements/{id}", disbursement.getId())
            .accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<Disbursement> disbursementList = disbursementRepository.findAll();
        assertThat(disbursementList).hasSize(databaseSizeBeforeDelete - 1);
    }
}
