package com.smeiob.demo.invoice.domain;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;
import com.smeiob.demo.invoice.web.rest.TestUtil;

public class DisbursementTest {

    @Test
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(Disbursement.class);
        Disbursement disbursement1 = new Disbursement();
        disbursement1.setId(1L);
        Disbursement disbursement2 = new Disbursement();
        disbursement2.setId(disbursement1.getId());
        assertThat(disbursement1).isEqualTo(disbursement2);
        disbursement2.setId(2L);
        assertThat(disbursement1).isNotEqualTo(disbursement2);
        disbursement1.setId(null);
        assertThat(disbursement1).isNotEqualTo(disbursement2);
    }
}
