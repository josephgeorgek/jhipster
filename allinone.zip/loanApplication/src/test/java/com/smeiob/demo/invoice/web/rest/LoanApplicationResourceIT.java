package com.smeiob.demo.invoice.web.rest;

import com.smeiob.demo.invoice.LoanApplicationApp;
import com.smeiob.demo.invoice.domain.LoanApplication;
import com.smeiob.demo.invoice.repository.LoanApplicationRepository;
import com.smeiob.demo.invoice.service.LoanApplicationService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;
import javax.persistence.EntityManager;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.smeiob.demo.invoice.domain.enumeration.LoanApplicationStatus;
import com.smeiob.demo.invoice.domain.enumeration.DisbursementMethod;
/**
 * Integration tests for the {@link LoanApplicationResource} REST controller.
 */
@SpringBootTest(classes = LoanApplicationApp.class)
@AutoConfigureMockMvc
@WithMockUser
public class LoanApplicationResourceIT {

    private static final String DEFAULT_CODE = "AAAAAAAAAA";
    private static final String UPDATED_CODE = "BBBBBBBBBB";

    private static final Instant DEFAULT_DATE = Instant.ofEpochMilli(0L);
    private static final Instant UPDATED_DATE = Instant.now().truncatedTo(ChronoUnit.MILLIS);

    private static final String DEFAULT_DETAILS = "AAAAAAAAAA";
    private static final String UPDATED_DETAILS = "BBBBBBBBBB";

    private static final LoanApplicationStatus DEFAULT_STATUS = LoanApplicationStatus.APPROVED;
    private static final LoanApplicationStatus UPDATED_STATUS = LoanApplicationStatus.PAID;

    private static final DisbursementMethod DEFAULT_PAYMENT_METHOD = DisbursementMethod.OD;
    private static final DisbursementMethod UPDATED_PAYMENT_METHOD = DisbursementMethod.ACCOUNT;

    private static final Instant DEFAULT_DISBUREMENT_DATE = Instant.ofEpochMilli(0L);
    private static final Instant UPDATED_DISBUREMENT_DATE = Instant.now().truncatedTo(ChronoUnit.MILLIS);

    private static final BigDecimal DEFAULT_AMOUNT = new BigDecimal(1);
    private static final BigDecimal UPDATED_AMOUNT = new BigDecimal(2);

    @Autowired
    private LoanApplicationRepository loanApplicationRepository;

    @Autowired
    private LoanApplicationService loanApplicationService;

    @Autowired
    private EntityManager em;

    @Autowired
    private MockMvc restLoanApplicationMockMvc;

    private LoanApplication loanApplication;

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static LoanApplication createEntity(EntityManager em) {
        LoanApplication loanApplication = new LoanApplication()
            .code(DEFAULT_CODE)
            .date(DEFAULT_DATE)
            .details(DEFAULT_DETAILS)
            .status(DEFAULT_STATUS)
            .paymentMethod(DEFAULT_PAYMENT_METHOD)
            .disburementDate(DEFAULT_DISBUREMENT_DATE)
            .amount(DEFAULT_AMOUNT);
        return loanApplication;
    }
    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static LoanApplication createUpdatedEntity(EntityManager em) {
        LoanApplication loanApplication = new LoanApplication()
            .code(UPDATED_CODE)
            .date(UPDATED_DATE)
            .details(UPDATED_DETAILS)
            .status(UPDATED_STATUS)
            .paymentMethod(UPDATED_PAYMENT_METHOD)
            .disburementDate(UPDATED_DISBUREMENT_DATE)
            .amount(UPDATED_AMOUNT);
        return loanApplication;
    }

    @BeforeEach
    public void initTest() {
        loanApplication = createEntity(em);
    }

    @Test
    @Transactional
    public void createLoanApplication() throws Exception {
        int databaseSizeBeforeCreate = loanApplicationRepository.findAll().size();
        // Create the LoanApplication
        restLoanApplicationMockMvc.perform(post("/api/loan-applications")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(loanApplication)))
            .andExpect(status().isCreated());

        // Validate the LoanApplication in the database
        List<LoanApplication> loanApplicationList = loanApplicationRepository.findAll();
        assertThat(loanApplicationList).hasSize(databaseSizeBeforeCreate + 1);
        LoanApplication testLoanApplication = loanApplicationList.get(loanApplicationList.size() - 1);
        assertThat(testLoanApplication.getCode()).isEqualTo(DEFAULT_CODE);
        assertThat(testLoanApplication.getDate()).isEqualTo(DEFAULT_DATE);
        assertThat(testLoanApplication.getDetails()).isEqualTo(DEFAULT_DETAILS);
        assertThat(testLoanApplication.getStatus()).isEqualTo(DEFAULT_STATUS);
        assertThat(testLoanApplication.getPaymentMethod()).isEqualTo(DEFAULT_PAYMENT_METHOD);
        assertThat(testLoanApplication.getDisburementDate()).isEqualTo(DEFAULT_DISBUREMENT_DATE);
        assertThat(testLoanApplication.getAmount()).isEqualTo(DEFAULT_AMOUNT);
    }

    @Test
    @Transactional
    public void createLoanApplicationWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = loanApplicationRepository.findAll().size();

        // Create the LoanApplication with an existing ID
        loanApplication.setId(1L);

        // An entity with an existing ID cannot be created, so this API call must fail
        restLoanApplicationMockMvc.perform(post("/api/loan-applications")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(loanApplication)))
            .andExpect(status().isBadRequest());

        // Validate the LoanApplication in the database
        List<LoanApplication> loanApplicationList = loanApplicationRepository.findAll();
        assertThat(loanApplicationList).hasSize(databaseSizeBeforeCreate);
    }


    @Test
    @Transactional
    public void checkCodeIsRequired() throws Exception {
        int databaseSizeBeforeTest = loanApplicationRepository.findAll().size();
        // set the field null
        loanApplication.setCode(null);

        // Create the LoanApplication, which fails.


        restLoanApplicationMockMvc.perform(post("/api/loan-applications")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(loanApplication)))
            .andExpect(status().isBadRequest());

        List<LoanApplication> loanApplicationList = loanApplicationRepository.findAll();
        assertThat(loanApplicationList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkDateIsRequired() throws Exception {
        int databaseSizeBeforeTest = loanApplicationRepository.findAll().size();
        // set the field null
        loanApplication.setDate(null);

        // Create the LoanApplication, which fails.


        restLoanApplicationMockMvc.perform(post("/api/loan-applications")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(loanApplication)))
            .andExpect(status().isBadRequest());

        List<LoanApplication> loanApplicationList = loanApplicationRepository.findAll();
        assertThat(loanApplicationList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkStatusIsRequired() throws Exception {
        int databaseSizeBeforeTest = loanApplicationRepository.findAll().size();
        // set the field null
        loanApplication.setStatus(null);

        // Create the LoanApplication, which fails.


        restLoanApplicationMockMvc.perform(post("/api/loan-applications")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(loanApplication)))
            .andExpect(status().isBadRequest());

        List<LoanApplication> loanApplicationList = loanApplicationRepository.findAll();
        assertThat(loanApplicationList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkPaymentMethodIsRequired() throws Exception {
        int databaseSizeBeforeTest = loanApplicationRepository.findAll().size();
        // set the field null
        loanApplication.setPaymentMethod(null);

        // Create the LoanApplication, which fails.


        restLoanApplicationMockMvc.perform(post("/api/loan-applications")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(loanApplication)))
            .andExpect(status().isBadRequest());

        List<LoanApplication> loanApplicationList = loanApplicationRepository.findAll();
        assertThat(loanApplicationList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkDisburementDateIsRequired() throws Exception {
        int databaseSizeBeforeTest = loanApplicationRepository.findAll().size();
        // set the field null
        loanApplication.setDisburementDate(null);

        // Create the LoanApplication, which fails.


        restLoanApplicationMockMvc.perform(post("/api/loan-applications")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(loanApplication)))
            .andExpect(status().isBadRequest());

        List<LoanApplication> loanApplicationList = loanApplicationRepository.findAll();
        assertThat(loanApplicationList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkAmountIsRequired() throws Exception {
        int databaseSizeBeforeTest = loanApplicationRepository.findAll().size();
        // set the field null
        loanApplication.setAmount(null);

        // Create the LoanApplication, which fails.


        restLoanApplicationMockMvc.perform(post("/api/loan-applications")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(loanApplication)))
            .andExpect(status().isBadRequest());

        List<LoanApplication> loanApplicationList = loanApplicationRepository.findAll();
        assertThat(loanApplicationList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllLoanApplications() throws Exception {
        // Initialize the database
        loanApplicationRepository.saveAndFlush(loanApplication);

        // Get all the loanApplicationList
        restLoanApplicationMockMvc.perform(get("/api/loan-applications?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(loanApplication.getId().intValue())))
            .andExpect(jsonPath("$.[*].code").value(hasItem(DEFAULT_CODE)))
            .andExpect(jsonPath("$.[*].date").value(hasItem(DEFAULT_DATE.toString())))
            .andExpect(jsonPath("$.[*].details").value(hasItem(DEFAULT_DETAILS)))
            .andExpect(jsonPath("$.[*].status").value(hasItem(DEFAULT_STATUS.toString())))
            .andExpect(jsonPath("$.[*].paymentMethod").value(hasItem(DEFAULT_PAYMENT_METHOD.toString())))
            .andExpect(jsonPath("$.[*].disburementDate").value(hasItem(DEFAULT_DISBUREMENT_DATE.toString())))
            .andExpect(jsonPath("$.[*].amount").value(hasItem(DEFAULT_AMOUNT.intValue())));
    }
    
    @Test
    @Transactional
    public void getLoanApplication() throws Exception {
        // Initialize the database
        loanApplicationRepository.saveAndFlush(loanApplication);

        // Get the loanApplication
        restLoanApplicationMockMvc.perform(get("/api/loan-applications/{id}", loanApplication.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.id").value(loanApplication.getId().intValue()))
            .andExpect(jsonPath("$.code").value(DEFAULT_CODE))
            .andExpect(jsonPath("$.date").value(DEFAULT_DATE.toString()))
            .andExpect(jsonPath("$.details").value(DEFAULT_DETAILS))
            .andExpect(jsonPath("$.status").value(DEFAULT_STATUS.toString()))
            .andExpect(jsonPath("$.paymentMethod").value(DEFAULT_PAYMENT_METHOD.toString()))
            .andExpect(jsonPath("$.disburementDate").value(DEFAULT_DISBUREMENT_DATE.toString()))
            .andExpect(jsonPath("$.amount").value(DEFAULT_AMOUNT.intValue()));
    }
    @Test
    @Transactional
    public void getNonExistingLoanApplication() throws Exception {
        // Get the loanApplication
        restLoanApplicationMockMvc.perform(get("/api/loan-applications/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateLoanApplication() throws Exception {
        // Initialize the database
        loanApplicationService.save(loanApplication);

        int databaseSizeBeforeUpdate = loanApplicationRepository.findAll().size();

        // Update the loanApplication
        LoanApplication updatedLoanApplication = loanApplicationRepository.findById(loanApplication.getId()).get();
        // Disconnect from session so that the updates on updatedLoanApplication are not directly saved in db
        em.detach(updatedLoanApplication);
        updatedLoanApplication
            .code(UPDATED_CODE)
            .date(UPDATED_DATE)
            .details(UPDATED_DETAILS)
            .status(UPDATED_STATUS)
            .paymentMethod(UPDATED_PAYMENT_METHOD)
            .disburementDate(UPDATED_DISBUREMENT_DATE)
            .amount(UPDATED_AMOUNT);

        restLoanApplicationMockMvc.perform(put("/api/loan-applications")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(updatedLoanApplication)))
            .andExpect(status().isOk());

        // Validate the LoanApplication in the database
        List<LoanApplication> loanApplicationList = loanApplicationRepository.findAll();
        assertThat(loanApplicationList).hasSize(databaseSizeBeforeUpdate);
        LoanApplication testLoanApplication = loanApplicationList.get(loanApplicationList.size() - 1);
        assertThat(testLoanApplication.getCode()).isEqualTo(UPDATED_CODE);
        assertThat(testLoanApplication.getDate()).isEqualTo(UPDATED_DATE);
        assertThat(testLoanApplication.getDetails()).isEqualTo(UPDATED_DETAILS);
        assertThat(testLoanApplication.getStatus()).isEqualTo(UPDATED_STATUS);
        assertThat(testLoanApplication.getPaymentMethod()).isEqualTo(UPDATED_PAYMENT_METHOD);
        assertThat(testLoanApplication.getDisburementDate()).isEqualTo(UPDATED_DISBUREMENT_DATE);
        assertThat(testLoanApplication.getAmount()).isEqualTo(UPDATED_AMOUNT);
    }

    @Test
    @Transactional
    public void updateNonExistingLoanApplication() throws Exception {
        int databaseSizeBeforeUpdate = loanApplicationRepository.findAll().size();

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restLoanApplicationMockMvc.perform(put("/api/loan-applications")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(loanApplication)))
            .andExpect(status().isBadRequest());

        // Validate the LoanApplication in the database
        List<LoanApplication> loanApplicationList = loanApplicationRepository.findAll();
        assertThat(loanApplicationList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    public void deleteLoanApplication() throws Exception {
        // Initialize the database
        loanApplicationService.save(loanApplication);

        int databaseSizeBeforeDelete = loanApplicationRepository.findAll().size();

        // Delete the loanApplication
        restLoanApplicationMockMvc.perform(delete("/api/loan-applications/{id}", loanApplication.getId())
            .accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<LoanApplication> loanApplicationList = loanApplicationRepository.findAll();
        assertThat(loanApplicationList).hasSize(databaseSizeBeforeDelete - 1);
    }
}
