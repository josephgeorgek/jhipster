package com.smeiob.demo.invoice.domain;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;
import com.smeiob.demo.invoice.web.rest.TestUtil;

public class LoanApplicationTest {

    @Test
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(LoanApplication.class);
        LoanApplication loanApplication1 = new LoanApplication();
        loanApplication1.setId(1L);
        LoanApplication loanApplication2 = new LoanApplication();
        loanApplication2.setId(loanApplication1.getId());
        assertThat(loanApplication1).isEqualTo(loanApplication2);
        loanApplication2.setId(2L);
        assertThat(loanApplication1).isNotEqualTo(loanApplication2);
        loanApplication1.setId(null);
        assertThat(loanApplication1).isNotEqualTo(loanApplication2);
    }
}
