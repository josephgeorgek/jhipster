package com.smeiob.demo.invoice.repository;

import com.smeiob.demo.invoice.domain.Disbursement;

import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

/**
 * Spring Data  repository for the Disbursement entity.
 */
@SuppressWarnings("unused")
@Repository
public interface DisbursementRepository extends JpaRepository<Disbursement, Long> {
}
