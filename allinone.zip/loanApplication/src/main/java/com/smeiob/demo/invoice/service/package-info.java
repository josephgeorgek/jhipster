/**
 * Service layer beans.
 */
package com.smeiob.demo.invoice.service;
