/**
 * JPA domain objects.
 */
package com.smeiob.demo.invoice.domain;
