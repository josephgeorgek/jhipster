/**
 * View Models used by Spring MVC REST controllers.
 */
package com.smeiob.demo.invoice.web.rest.vm;
