package com.smeiob.demo.invoice.repository;

import com.smeiob.demo.invoice.domain.LoanApplication;

import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

/**
 * Spring Data  repository for the LoanApplication entity.
 */
@SuppressWarnings("unused")
@Repository
public interface LoanApplicationRepository extends JpaRepository<LoanApplication, Long> {
}
