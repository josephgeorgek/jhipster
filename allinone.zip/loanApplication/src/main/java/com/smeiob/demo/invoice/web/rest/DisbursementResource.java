package com.smeiob.demo.invoice.web.rest;

import com.smeiob.demo.invoice.domain.Disbursement;
import com.smeiob.demo.invoice.service.DisbursementService;
import com.smeiob.demo.invoice.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.PaginationUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing {@link com.smeiob.demo.invoice.domain.Disbursement}.
 */
@RestController
@RequestMapping("/api")
public class DisbursementResource {

    private final Logger log = LoggerFactory.getLogger(DisbursementResource.class);

    private static final String ENTITY_NAME = "loanApplicationDisbursement";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final DisbursementService disbursementService;

    public DisbursementResource(DisbursementService disbursementService) {
        this.disbursementService = disbursementService;
    }

    /**
     * {@code POST  /disbursements} : Create a new disbursement.
     *
     * @param disbursement the disbursement to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new disbursement, or with status {@code 400 (Bad Request)} if the disbursement has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/disbursements")
    public ResponseEntity<Disbursement> createDisbursement(@Valid @RequestBody Disbursement disbursement) throws URISyntaxException {
        log.debug("REST request to save Disbursement : {}", disbursement);
        if (disbursement.getId() != null) {
            throw new BadRequestAlertException("A new disbursement cannot already have an ID", ENTITY_NAME, "idexists");
        }
        Disbursement result = disbursementService.save(disbursement);
        return ResponseEntity.created(new URI("/api/disbursements/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /disbursements} : Updates an existing disbursement.
     *
     * @param disbursement the disbursement to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated disbursement,
     * or with status {@code 400 (Bad Request)} if the disbursement is not valid,
     * or with status {@code 500 (Internal Server Error)} if the disbursement couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/disbursements")
    public ResponseEntity<Disbursement> updateDisbursement(@Valid @RequestBody Disbursement disbursement) throws URISyntaxException {
        log.debug("REST request to update Disbursement : {}", disbursement);
        if (disbursement.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        Disbursement result = disbursementService.save(disbursement);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, disbursement.getId().toString()))
            .body(result);
    }

    /**
     * {@code GET  /disbursements} : get all the disbursements.
     *
     * @param pageable the pagination information.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of disbursements in body.
     */
    @GetMapping("/disbursements")
    public ResponseEntity<List<Disbursement>> getAllDisbursements(Pageable pageable) {
        log.debug("REST request to get a page of Disbursements");
        Page<Disbursement> page = disbursementService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(ServletUriComponentsBuilder.fromCurrentRequest(), page);
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * {@code GET  /disbursements/:id} : get the "id" disbursement.
     *
     * @param id the id of the disbursement to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the disbursement, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/disbursements/{id}")
    public ResponseEntity<Disbursement> getDisbursement(@PathVariable Long id) {
        log.debug("REST request to get Disbursement : {}", id);
        Optional<Disbursement> disbursement = disbursementService.findOne(id);
        return ResponseUtil.wrapOrNotFound(disbursement);
    }

    /**
     * {@code DELETE  /disbursements/:id} : delete the "id" disbursement.
     *
     * @param id the id of the disbursement to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/disbursements/{id}")
    public ResponseEntity<Void> deleteDisbursement(@PathVariable Long id) {
        log.debug("REST request to delete Disbursement : {}", id);
        disbursementService.delete(id);
        return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString())).build();
    }
}
