package com.smeiob.demo.invoice.domain.enumeration;

/**
 * The DisbursementMethod enumeration.
 */
public enum DisbursementMethod {
    OD, ACCOUNT, GIRO
}
