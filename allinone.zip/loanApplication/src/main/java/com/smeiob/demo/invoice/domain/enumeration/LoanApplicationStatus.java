package com.smeiob.demo.invoice.domain.enumeration;

/**
 * The LoanApplicationStatus enumeration.
 */
public enum LoanApplicationStatus {
    APPROVED, PAID, ISSUED, CANCELLED
}
