/**
 * Audit specific code.
 */
package com.smeiob.demo.invoice.config.audit;
