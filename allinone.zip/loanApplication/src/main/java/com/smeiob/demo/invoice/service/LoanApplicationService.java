package com.smeiob.demo.invoice.service;

import com.smeiob.demo.invoice.domain.LoanApplication;
import com.smeiob.demo.invoice.repository.LoanApplicationRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

/**
 * Service Implementation for managing {@link LoanApplication}.
 */
@Service
@Transactional
public class LoanApplicationService {

    private final Logger log = LoggerFactory.getLogger(LoanApplicationService.class);

    private final LoanApplicationRepository loanApplicationRepository;

    public LoanApplicationService(LoanApplicationRepository loanApplicationRepository) {
        this.loanApplicationRepository = loanApplicationRepository;
    }

    /**
     * Save a loanApplication.
     *
     * @param loanApplication the entity to save.
     * @return the persisted entity.
     */
    public LoanApplication save(LoanApplication loanApplication) {
        log.debug("Request to save LoanApplication : {}", loanApplication);
        return loanApplicationRepository.save(loanApplication);
    }

    /**
     * Get all the loanApplications.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    @Transactional(readOnly = true)
    public Page<LoanApplication> findAll(Pageable pageable) {
        log.debug("Request to get all LoanApplications");
        return loanApplicationRepository.findAll(pageable);
    }


    /**
     * Get one loanApplication by id.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    @Transactional(readOnly = true)
    public Optional<LoanApplication> findOne(Long id) {
        log.debug("Request to get LoanApplication : {}", id);
        return loanApplicationRepository.findById(id);
    }

    /**
     * Delete the loanApplication by id.
     *
     * @param id the id of the entity.
     */
    public void delete(Long id) {
        log.debug("Request to delete LoanApplication : {}", id);
        loanApplicationRepository.deleteById(id);
    }
}
