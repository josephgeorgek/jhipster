package com.smeiob.demo.invoice.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.HashSet;
import java.util.Set;

import com.smeiob.demo.invoice.domain.enumeration.LoanApplicationStatus;

import com.smeiob.demo.invoice.domain.enumeration.DisbursementMethod;

/**
 * A LoanApplication.
 */
@Entity
@Table(name = "loan_application")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class LoanApplication implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @Column(name = "code", nullable = false)
    private String code;

    @NotNull
    @Column(name = "date", nullable = false)
    private Instant date;

    @Column(name = "details")
    private String details;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private LoanApplicationStatus status;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "payment_method", nullable = false)
    private DisbursementMethod paymentMethod;

    @NotNull
    @Column(name = "disburement_date", nullable = false)
    private Instant disburementDate;

    @NotNull
    @Column(name = "amount", precision = 21, scale = 2, nullable = false)
    private BigDecimal amount;

    @OneToMany(mappedBy = "invoice")
    @Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
    private Set<Disbursement> shipments = new HashSet<>();

    // jhipster-needle-entity-add-field - JHipster will add fields here
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public LoanApplication code(String code) {
        this.code = code;
        return this;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Instant getDate() {
        return date;
    }

    public LoanApplication date(Instant date) {
        this.date = date;
        return this;
    }

    public void setDate(Instant date) {
        this.date = date;
    }

    public String getDetails() {
        return details;
    }

    public LoanApplication details(String details) {
        this.details = details;
        return this;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public LoanApplicationStatus getStatus() {
        return status;
    }

    public LoanApplication status(LoanApplicationStatus status) {
        this.status = status;
        return this;
    }

    public void setStatus(LoanApplicationStatus status) {
        this.status = status;
    }

    public DisbursementMethod getPaymentMethod() {
        return paymentMethod;
    }

    public LoanApplication paymentMethod(DisbursementMethod paymentMethod) {
        this.paymentMethod = paymentMethod;
        return this;
    }

    public void setPaymentMethod(DisbursementMethod paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public Instant getDisburementDate() {
        return disburementDate;
    }

    public LoanApplication disburementDate(Instant disburementDate) {
        this.disburementDate = disburementDate;
        return this;
    }

    public void setDisburementDate(Instant disburementDate) {
        this.disburementDate = disburementDate;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public LoanApplication amount(BigDecimal amount) {
        this.amount = amount;
        return this;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public Set<Disbursement> getShipments() {
        return shipments;
    }

    public LoanApplication shipments(Set<Disbursement> disbursements) {
        this.shipments = disbursements;
        return this;
    }

    public LoanApplication addShipment(Disbursement disbursement) {
        this.shipments.add(disbursement);
        disbursement.setInvoice(this);
        return this;
    }

    public LoanApplication removeShipment(Disbursement disbursement) {
        this.shipments.remove(disbursement);
        disbursement.setInvoice(null);
        return this;
    }

    public void setShipments(Set<Disbursement> disbursements) {
        this.shipments = disbursements;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof LoanApplication)) {
            return false;
        }
        return id != null && id.equals(((LoanApplication) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "LoanApplication{" +
            "id=" + getId() +
            ", code='" + getCode() + "'" +
            ", date='" + getDate() + "'" +
            ", details='" + getDetails() + "'" +
            ", status='" + getStatus() + "'" +
            ", paymentMethod='" + getPaymentMethod() + "'" +
            ", disburementDate='" + getDisburementDate() + "'" +
            ", amount=" + getAmount() +
            "}";
    }
}
