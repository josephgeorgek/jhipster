/**
 * Spring Security configuration.
 */
package com.smeiob.demo.invoice.security;
