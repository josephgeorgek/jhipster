package com.smeiob.demo.invoice.web.rest;

import com.smeiob.demo.invoice.domain.LoanApplication;
import com.smeiob.demo.invoice.service.LoanApplicationService;
import com.smeiob.demo.invoice.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.PaginationUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing {@link com.smeiob.demo.invoice.domain.LoanApplication}.
 */
@RestController
@RequestMapping("/api")
public class LoanApplicationResource {

    private final Logger log = LoggerFactory.getLogger(LoanApplicationResource.class);

    private static final String ENTITY_NAME = "loanApplicationLoanApplication";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final LoanApplicationService loanApplicationService;

    public LoanApplicationResource(LoanApplicationService loanApplicationService) {
        this.loanApplicationService = loanApplicationService;
    }

    /**
     * {@code POST  /loan-applications} : Create a new loanApplication.
     *
     * @param loanApplication the loanApplication to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new loanApplication, or with status {@code 400 (Bad Request)} if the loanApplication has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/loan-applications")
    public ResponseEntity<LoanApplication> createLoanApplication(@Valid @RequestBody LoanApplication loanApplication) throws URISyntaxException {
        log.debug("REST request to save LoanApplication : {}", loanApplication);
        if (loanApplication.getId() != null) {
            throw new BadRequestAlertException("A new loanApplication cannot already have an ID", ENTITY_NAME, "idexists");
        }
        LoanApplication result = loanApplicationService.save(loanApplication);
        return ResponseEntity.created(new URI("/api/loan-applications/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /loan-applications} : Updates an existing loanApplication.
     *
     * @param loanApplication the loanApplication to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated loanApplication,
     * or with status {@code 400 (Bad Request)} if the loanApplication is not valid,
     * or with status {@code 500 (Internal Server Error)} if the loanApplication couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/loan-applications")
    public ResponseEntity<LoanApplication> updateLoanApplication(@Valid @RequestBody LoanApplication loanApplication) throws URISyntaxException {
        log.debug("REST request to update LoanApplication : {}", loanApplication);
        if (loanApplication.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        LoanApplication result = loanApplicationService.save(loanApplication);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, loanApplication.getId().toString()))
            .body(result);
    }

    /**
     * {@code GET  /loan-applications} : get all the loanApplications.
     *
     * @param pageable the pagination information.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of loanApplications in body.
     */
    @GetMapping("/loan-applications")
    public ResponseEntity<List<LoanApplication>> getAllLoanApplications(Pageable pageable) {
        log.debug("REST request to get a page of LoanApplications");
        Page<LoanApplication> page = loanApplicationService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(ServletUriComponentsBuilder.fromCurrentRequest(), page);
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * {@code GET  /loan-applications/:id} : get the "id" loanApplication.
     *
     * @param id the id of the loanApplication to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the loanApplication, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/loan-applications/{id}")
    public ResponseEntity<LoanApplication> getLoanApplication(@PathVariable Long id) {
        log.debug("REST request to get LoanApplication : {}", id);
        Optional<LoanApplication> loanApplication = loanApplicationService.findOne(id);
        return ResponseUtil.wrapOrNotFound(loanApplication);
    }

    /**
     * {@code DELETE  /loan-applications/:id} : delete the "id" loanApplication.
     *
     * @param id the id of the loanApplication to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/loan-applications/{id}")
    public ResponseEntity<Void> deleteLoanApplication(@PathVariable Long id) {
        log.debug("REST request to delete LoanApplication : {}", id);
        loanApplicationService.delete(id);
        return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString())).build();
    }
}
